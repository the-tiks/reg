<main>
<div class="container">
      <div class="left-col">
      
       <h3>K9 Patrols</h3>
      <img src="../images/k9-4.jpg" width="300px" height="300px">
      <a href="LoginForm.php"><button class="rqif" name="K9-pat">Login to Request Information</button></a>

      </div>
      <div class="second-col">

      <h3>VIP Close Personnel Protection</h3>
      <img src="../images/vip.jpg"width="300px" height="300px">
      <a href="LoginForm.php"><button class="rqif" name="VIP-protect">Login to Request Information</button></a>

      </div>
      <div class="third-col">

      
      <h3>Armed Escort</h3>
      <img src="../images/amd2.jpg" width="300px" height="300px">
      <a href="LoginForm.php"><button class="rqif" name="Armed-Es">Login to Request Information</button></a>

      </div>
      <div class="right-col">

      <h3>Physical Guarding</h3>
      <img src="../images/bdg.jpg" width="300px" height="300px">
      <a href="LoginForm.php"><button class="rqif" name="Guard">Login to Request Information</button></a>
                   
   </div>
</div>
<div class="small_view">
      
      <h3>K9 Patrols</h3>
     <img  class="image" src="../images/k9-4.jpg" width="300px" height="300px">
     <a href="LoginForm.php"><br><button class="rqif" name="K9-pat">Login to Request Information</button></a><br>

     <h3>Armed Escort</h3>
      <img class="image" src="../images/amd2.jpg" width="300px" height="300px">
      <a href="LoginForm.php"><br><button class="rqif" name="Armed-Es">Login to Request Information</button></a><br>

     <h3>VIP Close Personnel Protection</h3>
     <img class="image" src="../images/vip.jpg"width="300px" height="300px">
     <a href="LoginForm.php"><br><button class="rqif" name="VIP-protect">Login to Request Information</button></a><br>

     <h3>Physical Guarding</h3>
      <img class="image" src="../images/bdg.jpg" width="300px" height="300px">
      <a href="LoginForm.php"><br><button class="rqif" name="Guard">Login to Request Information</button></a><br>

    
   </div>
</main>
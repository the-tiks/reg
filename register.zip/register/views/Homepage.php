<?php
    session_start();
    include '../scripts/php/createInvoice.php';
    include '../scripts/php/comments.php';
    date_default_timezone_set('Africa/Johannesburg');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baipushi Security Services</title>
    <meta http-equiv="refresh" content="300" > 
	<link rel="stylesheet" type="text/css" href="../styles/style.css">
</head>
<body>
    <?php 
    if(isset($_SESSION["id"])){
        if((time() - $_SESSION['last_login_timestamp']) > 1800){
            header("Location: ../scripts/php/SesExpire.php");
            exit();
        }
        echo'';
    }
    else{
        header("location: ../index.php");
        exit();
    }
    ?>
    <div class="grid">
        <div class="backdrop"></div>
        <header class="main-header">
            <button id="side-menu-toggle">Menu</button>
            <div class="logo">
                    <a href="#"><img src="../images/logo.png" height=55 width=300></a>
                </div>
            <nav class="main-header__nav">
                <ul class="main-header__item-list">
                    <li class="main-header__item">
                        <a  href="#" target="_blank"> Shop</a>
                    </li>
                    <li class="main-header__item">
                        <a  href="contact_us.php" target="_blank">Contact</a>
                    </li>
                    <li class="main-header__item">
                        <a href="chat.php" target="_blank">Chat</a>
                    </li>
                    <li class="main-header__item">
                        <a href="Services.php" target="_blank">Services</a>
                    </li>
                    <li class="main-header__item">
                        <a href="EditProfile.php" target="_blank">Profile
                        </a>
                    </li>
                    <li class="main-header__item">
                      <form method="POST" action="../scripts/php/logout.php">
                          <button id="logoutBtn" name="user_logout">Logout</button>
                      </form>
                    </li>
                </ul>
            </nav>
        </header>
        <nav class="mobile-nav">
            <ul class="mobile-nav__item-list">
                    <li class="mobile-nav__item">
                        <a  href="EditProfile.php" target="_blank">Profile</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="Services.php" target="_blank">Services</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="contact_us.php" target="_blank">Email us</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="chat.php" target="_blank">Live Chat</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="#">Follow Us
                        </a>
                        <ul>
                            <div class="icons">
                                <li><a href="#" target="_blank"><img src="../images/fb-icon.jpg"
                                                width= "30px"
                                                height= "30px"></a></li>
                                <li><a href="#" target="_blank"><img src="../images/twtr-icon.jpg"
                                                width= "30px" 
                                                height= "30px"></a></li>
                                <li><a href="#" target="_blank"><img src="../images/ig-icon.jpg"
                                                width= "30px"
                                                height= "30px"></a></li>
                            </div>
                        </ul>
                    </li>
                    <li class="mobile-nav__item">
                        <form method="POST" action="../scripts/php/logout.php">
                            <button id="Btn" name="user_logout">Logout</button>
                        </form>
                    </li>
                </ul>
    </nav>
    <script src="../scripts/js/main.js"></script>
    <?php
        if(isset($_GET["login"])){
            if($_GET["login"]=="success"){
                echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Welcome Back ".$_SESSION['username']."</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
            }
        }
        elseif (isset($_GET["delete"])) {
            if($_GET["delete"]=="success"){
                echo"
            <div class='success_message-popup'>
                <div class='box'>
                    <div class='close'>&times;</div>
                    <p>Comment deleted</p>
                </div>
            </div>
            <script src='../scripts/js/success_messages.js'></script>";
            }
        }
    ?>
    <div class="content-area">
        <hr>
        <div class="Cont">
            <div class="Left_Column">
                <h2>My Invoices</h2>
                <?php
                echo"<form class='Invoices'>
                        ".getUserInvoices($conn)."
                    </form>";
                ?>
                <?php
                    echo "
                    ".getUserInvoicesSmallScreen($conn)."
                    ";
                ?>
            </div>

            <div class="Mid_Column">
                <h2>Services</h2>
            <a href="K9PatrolQuote.php" target="_blank"> <img src="../images/K9-4.jpg" width=150 height=150><p>We Offer K9 Patrol units to guard around homes, estates, 
                as well as Police force. Our Dogs are also trained to sniff out narcotics.</p></a>
                   <a href="VIPQuote.php" target="_blank"><img src="../images/vip.jpg" width=150 height=150><p>Our VIP Close Personnel Protection details offers a 
                       24 Hour VIP protection and escort at events or to serve as a protection detail.</p></a><br>
                   <a href="GuardQuote.php" target="_blank"><img src="../images/bdg.jpg" width=150 height=150><p>Our Body guarding detail offers a 24 hour protection and 
                       escort at events and private properties. Also includes 24 hour surveillance at private properties.</p></a>
                   <a href="ArmedEsQuote.php" target="_blank"><img src="../images/amd2.jpg" width=150 height=150><p>Our Armred Escort services offers a 24 hour armred 
                       response and surveillance on private protection, events, and events with high profile people. We also offer Armred Escort 
                       to high profile people</p></a>
            </div>

            <div class="Right_Column">
                <h2>Reviews And Comments</h2>
                <iframe with=100% height=75% src='userComments.php' frameborder=0></iframe>  
                   
            </div>
        </div>
    
  
    </div>
    
    </div>
   
</body>
<footer>
		
        <div class="container">
            <div class="col-1">
                    <label>Where Are Located</label>
            </div>
    
            <div class="col-2">
                <label>Get in touch with us</label><br>
                <a href="contact_us.php"><i class="far fa-envelope"></i>Send us an Email</a><br>
                <a href="chat.php" target="_blank">Live chat</a>
                <p><i class="far fa-phone"></i>Call us on (+27)87 630 0257</p>
            </div>
    
            <div class="col-3">
                    <label>Get Quotation</label><br>
                    <a href="K9PatrolQuote.php">Get K9 Patrol Unit quotation</a><br>
                    <a href="GuardQuote.php">Get Physical Guard service quotation</a><br>
                    <a href="ArmedEsQuote.php">Get Our Armed Escort service quotation</a><br>
                    <a href="VIPQuote.php">VIP Close Personnel Protection quotation</a>
            </div>
    
            <div class="col-4">
                <label>Follow Us</label>
                    <div class="icons">
                        <a href="https://facebook.com" target="_blank"><img src="../images/fb-icon.jpg"
                                            width= "25px"
                                            height= "25px"></a><span></span>
                        <a href="https://twitter.com" target="_blank"><img src="../images/twtr-icon.jpg"
                                            width= "25px" 
                                            height= "25px"></a><span></span>
                        <a href="https://instagram.com" target="_blank"><img src="../images/ig-icon.jpg"
                                            width= "25px"
                                            height= "25px"></a>
    
                    </div>
            </div>
        </div>
    </footer>
</html>
<?php
session_start();
?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../styles/ServStyling.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="30" > 
    <title>Services</title>
</head>
<body>
   
<header>
   <h2>p</h2>
   <h1>S E R V I C E S</h1>
   <hr>
</header>
<div class="Content-area">
<?php if(isset($_SESSION["id"]) || isset($_SESSION["empId"]) ){
      include 'services-display.php';
   ;
}
else{
      include 'services-hide.php';
}
?>
<a href="Homepage.php"><img src="https://img.icons8.com/ios/50/000000/backspace.png" 
        width="50px"
         height="40px"></a>
</div>
    
</body>
</hmtl>
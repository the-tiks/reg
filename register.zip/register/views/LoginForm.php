<?php
session_start();
?>
<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login</title> 
    <link rel="stylesheet" href="../styles/StyleSheet1.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="30" > 
</head>
<body>
    <?php
    if(isset($_SESSION["id"]) || isset($_SESSION["empId"]) || isset($_SESSION["adminId"])){
        header("Location: home.php");
        exit();
    }else{
        echo'';
    }
    ?>
<a href="Homepage.php"><img src="https://img.icons8.com/ios/50/000000/backspace.png" 
        width="50px"
         height="40px"></a>
         <?php
        if(isset($_GET["error"])){
            if($_GET["error"]=="emptyfields"){
                echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Fill In All Fields!!!</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
            }elseif ($_GET["error"]=="WrongDetails") {
                echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Incorrect email or password!!!</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
            }
        }
        elseif (isset($_GET["signup"])) {
            if($_GET["signup"]=="success"){
                echo"
                <div class='success_message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Account created successfully, login here</p>
                    </div>
                </div>
                <script src='../scripts/js/success_messages.js'></script>";
                
            }
        }
        elseif (isset($_GET["ress"])) {
            if($_GET["ress"]=="success"){
                echo"
                <div class='success_message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Password reset successfully, login here</p>
                    </div>
                </div>
                <script src='../scripts/js/success_messages.js'></script>";
            }
        }
    ?>
    <div class="Login_Form">
        <form method="post" class="form" action="../scripts/php/LoginUser.php">
        
        <h1>Login</h1>
        <hr>
        <label>Email:</label>
        <input type="email" name="email" placeholder="Enter your email" required/>
        <label>Password:</label>
        <input type="password" name="pwd" placeholder="Enter your password" required /><br><br>
        <button type="submit" name ="Login" id="bt">Login</button><br><br>
        <a class="resetPass" href="ResetPass.php">Forgot Password?</a>
        <a class="register" href="RegisterForm - Copy.php">Don't have an account? SignUp here</a>
        </form>
    </div>
    <script src="../scripts/script.js"></script>
</body>
</html>
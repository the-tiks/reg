<?php
    session_start();
    include '../scripts/php/comments.php';
    date_default_timezone_set('Africa/Johannesburg');
   /* if(isset($_GET["delete"])){
        if($_GET["delete"]=="success"){
            header("Location: Homepage.php?delete=success");
        }
    }*/

                echo "<style text='css/stylesheet'>
                    .comments{
                        width: 100%;
                        height: 100px; 
                        
                    }
                    textarea{
                        width: 100%;
                        height: 50px;
                      
                        font-family: inherit;
                        border: 2px solid #0476aa;
                    }
                    textarea:focus{
                        outline: #22d336;
                        border: 2px solid #22d336;
                    }
                    #cmntBtn{
                        background: #0476aa;
                        color: #fff;
                        height: 30px;
                        margin-top: 10px;
                        margin-left: 10%;
                        width: 75%;
                        border: 0;
                        border-radius: 5px;
                        cursor: pointer;
                        text-transform: uppercase;
                      }
                      #cmntBtn:hover{
                        background: #22d336;
                        color: #fff;
                        transition: 0.5s;
                        cursor: pointer;
                      }
                </style>
                <form class='comments' method='POST' action='".commentsOnLogin($conn)."'>
                    <input type='hidden' name='UserName' value='".$_SESSION["username"]."'>
                    <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
                    <textarea name='message' required></textarea><br>
                    <button id='cmntBtn' name='comment-submit'>comment</button>
                </form>
                ";
                echo "
                <style text='css/stylesheet'>
                      .Cmnt-box{
                          width: 100%;
                      }
                      p{
                          text-algin: left;
                          color: black;
                          font-family: sans-serif;
                      }
                </style>
                <div class='Cmnt-box'>
                <p>".getComments($conn)."</p>
                </div>";
            
                 
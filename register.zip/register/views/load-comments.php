<?php
    include "../scripts/php/db_conn.php";

    $commentNewCount = $_POST['commentNewCount'];
    
            $sql = "SELECT * FROM comments LIMIT $commentNewCount";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result)>0){
                while($row = mysqli_fetch_assoc($result)){
                    echo "<p>";
                    echo "<label>".$row["uid"]."</label>";
                    echo "<p class='comment'>".$row["message"]."</p>";
                    echo "<p class='date'>".$row["date"]."</p><br>";
                    echo "</p>";
                    echo "<hr>";
                }

            }else{
                echo 'there are no comments';
            }
        ?>
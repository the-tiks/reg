<?php
    session_start();
    include '../scripts/php/createInvoice.php';
    include '../scripts/php/ManageEmployees.php';
?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../styles/AdmnStylng.css"/>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
    <?php
    if(isset($_SESSION["adminId"])){

        if((time() - $_SESSION['last_login_timestamp']) > 2800){
            header("Location: ../scripts/php/SesExpire.php");
            exit();
        }
             echo'';
    }else{
        header("Location: Homepage.php");
        exit();
    }
    ?>

<header>
        <div class="wrapper"> 
            <label class="logo"><a href="Homepage.php"><img src="../images/logo.png" height=50 width=250></a></label>
        </div>
        <nav>
            <ul>
                <li><a class="bn" href="#">Services</a></li>
                <li><a class="bn" href="#">Services</a></li>
                <li><a class="bn" href="#">Profile</a></li>
                <li>
                    <form method="POST" action='../scripts/php/logout.php'>
                        <button id="logoutBtn" name="logout">Logout</button>
                    </form>
                </li>
            </ul>
            
    </nav>
    
    </header>
    <?php
        if(isset($_GET["login"])){
            if($_GET["login"]=="Success"){
                echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Welcome Back ".$_SESSION['username']."</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
            }
        }
    ?>
    <main>
        <div class="content-area">
            <div class="left-side">
                <div class="invoices">
                    <h1>Invoices</h1>
                    <?php
                    echo "
                        ".getAllInvoices($conn)."
                        ";
                    ?>
                    <h1>Messages</h1>

                </div>
            </div>

            <div class="right-side">
                <div class="other-stuff">
                <form method="post" action="../scripts/php/addEmp.php">
                <h1>Add Employee Record</h1>
            <table>
                <caption> </caption>
                <tr>
                    <td>Name:</td>
                    <td><input type="text" name="name" required></td>
                </tr>
                <tr>
                    <td>Lastame:</td>
                    <td><input type="text" name="Lastname" required></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="email" name="email_ad" required></td>
                </tr>
                <tr>
                    <td>Position:</td>
                    <td><input type="text" name="Pos" required></td>
                </tr>
                <tr>
                    <td>Salary:</td>
                    <td><input type="text" name="Salary" required></td>
                </tr>
                <tr>
                    <td>Phone:</td>
                    <td><input type="text" name="ContactNum" required></td>
                </tr><br>
                
            </table>
            <button id="btn" type="submit" name="regUser" >Add Employee</button>
        </form>

        
                  <?php
                    if(isset($_GET["error"])){
                                if ($_GET["error"]=="empnotfound") {
                                        echo'<p class="error-msg">No account with this email exits</p>';
                                    }
                                    elseif($_GET["error"]=="InvalidEmail"){
                                        echo'<p class="error-msg">This email is invalid';
                                    }
                                    
                                }
                                
                    echo"<form class='updEmp' method='post' action='".searchEmployee($conn)."'>
                            <h1>Update Employee Record</h1>
                            <label>Email:</label>
                            <input type='email' name='EmailId' placeholder='Enter email address' required>
                            <button type='submit'  name='UpdateRecord-submit' id='btn'>Search</button>
                        </form>";
                 ?>

                 
                 <?php

                    if(isset($_GET["error"])){
                        if($_GET["error"]=="InvalidEmail"){
                            echo'<p class="error-msg">This email is invalid';
                        }
                        elseif($_GET["error"]=="MailDntExist"){
                            echo'<p class="error-msg">No existing record registered with this email</p>';

                        }
                    }

                    elseif(isset($_GET["clear"])){
                        if($_GET["clear"]=="success"){
                            echo'<p class="success-msg">Record deleted successfully</p>';
                        }
                    }
                    echo"<style>
                            .deleteRecord{
                                box-shadow: 0 2px 8px #000;
                                width: 90%;
                                margin: 60px auto 0;
                                position: relative;
                                margin-top: 10px;
                                -webkit-border-radius: 10px 10px 10px 10px;
                                -moz-border-radius: 10px 10px 10px 10px;
                                border-radius: 10px 10px 10px 10px;
                               
                            }
                            .deleteRecord h1{
                                margin-top: 0px;
                                width: 100%;
                                background: #071b30fa;
                                color: #fff;
                                font-family: sans-serif;
                                text-align: center;
                                font-size: 25px;
                                height: 30px;
                            }
                            .deleteRecord label{
                                font-family: sans-serif;
                                font-weight: bold;
                                margin-top: 15px;
                                color: #071b30fa;
                                
                            }
                            .deleteRecord label, .deleteRecord button{
                                padding: 2%;
                                width: 100%;
                                margin-bottom: 10px;
                                
                            }
                            .deleteRecord input{
                                padding: 2%;
                                margin-left: 10px;
                                width: 90%;
                                border: 0;
                                border-bottom: 2px solid #071b30fa;
                            }
                            .deleteRecord input:focus{
                                outline: tomato;
                                border: 0;
                                border-bottom: 2px solid tomato;
                            }
                        </style>
                        
                        <form method='post' class='deleteRecord' action='".deleteRecord($conn)."'> 
                            <h1>Delete Record</h1>
                            <label>Email:</label><br>
                            <input type='email' name='mailId' placeholder='Enter email address' required><br>
                            <button type='submit' name='deleteRecord-submit' id='btn'>Delete Record</button>
                        </form>
                    ";
            ?>
            </div>

            
                </div>
            </div>
        </div>
    </main>
</body>
</html>
<?php
session_start();
date_default_timezone_set('Africa/Johannesburg');
include "../scripts/php/createInvoice.php";
include '../scripts/php/getMessage.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Baipushi Security Services</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../styles/EmpHomeStyling.css">
    
</head>
<body>

<?php
    if(isset($_SESSION["empId"])){

        if((time() - $_SESSION['last_login_timestamp']) > 1800){
            header("Location: ../scripts/php/SesExpire.php");
            exit();
        }
        echo '';
        
    }
    else{
        header("Location: Homepage.php");
        exit();
    }
?>
<nav>
        
        <label class="logo"><img src="logo.PNG" width="300px" height="50px"></label>
        <ul>
            <li><a class="bn" href="#">Home</a></li>
            <li><a class="bn"  href="#">About</a></li>
            <li><a class="bn"  href="../Views/Services.php">Services</a></li>
            <li><a class="bn"  href="#">Contact</a></li>
            <li><a class="btn" href="#"><form action="../scripts/php/logout.php" method="post"><button type="submit" class="lgBtn" name="logout">logout</button></form></a></li>
        </ul>
    </nav><br>
    <?php
            if(isset($_GET["error"])){
                if($_GET["error"]=="check"){
                    echo"
                    <div class='message-popup'>
                        <div class='box'>
                            <div class='close'>&times;</div>
                            <p>Check at least one box</p>
                        </div>
                    </div>
                    <script src='../scripts/js/error_messages.js'></script>";
                }
            }
            elseif (isset($_GET["login"])) {
                if ($_GET["login"] == "success") {
                    echo"
                    <div class='success_message-popup'>
                        <div class='box'>
                            <div class='close'>&times;</div>
                            <p>Welcome Back ".$_SESSION["emp_mail"]." :-)</p>
                        </div>
                    </div>
                    <script src='../scripts/js/success_messages.js'></script>";
                }
            }
            elseif (isset($_GET["invoice"])) {
                if($_GET["invoice"]=="succcess"){
                    echo"
                    <div class='success_message-popup'>
                        <div class='box'>
                            <div class='close'>&times;</div>
                            <p>Invoice Added Successfully:-)</p>
                        </div>
                    </div>
                    <script src='../scripts/js/success_messages.js'></script>";
                }
            }
        ?>
    <div class="container">
    <h2>p</h2>
   
    <div class="left-col">
    <form method="post" class="SendQ" action="../scripts/php/SendQ.php">
    <h3>Send Quoation(s)</h3>
    
        <?php
            if(isset($_GET["error"])){
                if($_GET["error"]=="check"){
                    echo'<p class="error-msg">Check the necessary boxes</p>';
                }
            }
        ?>
    
            <label>Recepient Email:</label>
            <input type="email" id="email" name="mail_id" placeholder="Enter email address"  required><br>
            <label>Select Quotation(s):</label><br>
            <input type="checkbox" name="K9Quote"  >K9 Patrols Quote</input><br>
            <input type="checkbox" name="GQuote" >Physical Guard Quote</input><br>
            <input type="checkbox" name="AEQuote" >Armed Escort Quote</input><br>
            <input type="checkbox" name="VIPQuote" >VIP Personal Protection Quote</input><br>
            <input type="submit" class="lgBtn" id="snd" name="Quote-send-submit" value="Send Quotation" required>
        </form>

     </div>
     <div class="right-col">
     
         <h1>Invoices</h1>
         
         <?php
         echo"
         <div class='success_message-popup'>
             <div class='box'>
                 <div class='close'>&times;</div>
                 <p>Invoice Added Successfully:-)</p>
             </div>
         </div>
         <script src='../scripts/js/success_messages.js'></script>";
         
         echo"
         <style text='css/stylesheet'>
            .GenInvoice {
                display: inline;
                height: 150px;
                background: #fff;
                margin-top: 5%;
                
            }
            .GenInvoice input{
                background: transparent;
                height: 40px;
                border: 0;
                border-bottom: 2px solid #1b9bff;
                border-left: 2px solid #1b9bff;
                border-radius: 3px;
                margin-top: 1%;
                margin-bottom: 1%;
            }
            .GenInvoice input:focus{
                outline: green;
                border: 0;
                border-left: 2px solid green;
                border-bottom: 2px solid green;

            }
            .GenInvoice button{
                width: 138px;
                height: 40px;
                color: #fff;
                background: #1b9bff;
                border: 1px;
                border-radius: 4px;
                text-transform: uppercase;
                cursor: pointer
            }
            .GenInvoice button:hover{
                background: #fff;
                border: 2px solid green;
                color: green;
            }
            .GenInvoice button:focus{
                outline: none;
            }
         </style>

             <form method='post' action='../scripts/php/createInvoice.php' class='GenInvoice'>
             <input type='text' name='serv' placeholder='Service rendered' required>
             <input type='text' name='dur' placeholder='Duration' required>
             <input type='date' name='date' placeholder='Date' required>
             <input type='text' name='price' placeholder='Cost' required>
             <input type='email' name='Customer-email' placeholder='Enter customer email' required>
             <input type='hidden' name='Invoice_date' value='".date('Y-m-d H:i:s')."'>
             <input type='hidden' name='issued_by' value='".$_SESSION["emp_name"]. " ".$_SESSION["emp_lastname"]."'>
             <input type='hidden' name='emp_id' value=".$_SESSION["empId"].">
             <button type='submit' name='create_Invoice'>Submit</button>
             </form>
             ";
             echo"<hr>";
             echo"".getInvoices($conn)."";
             echo "
             ".getMessages($conn).""
             ?>
         
    
     </div>
    </div><br>
</div>
        
</body>
</html>
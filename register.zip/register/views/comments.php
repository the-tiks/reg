<?php
    include '../scripts/php/db_conn.php';
    include '../scripts/php/comments.php';
    date_default_timezone_set('Africa/Johannesburg');
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments</title>
    <style>
        *:focus{
            outline: none;
            }
        div{
            width: 98%;
            margin: 1%;
            padding: 2px;
            border: 2px solid #000;
            background-color: #fff;
            font-family: sans-serif;
        }
        .box{
            margin-top: 15px;
        }
        label{
                 font-weight: bold;
                font-family: sans-serif;
                float: left;
                text-align: left;
                color: #0476aa;
                width: 100%;
                margin: 0;
        }
        .date{
                float: right;
                width: 100%;
                text-align: right;
                font-size: 12px;
                font-weight: bold;
                margin-top: 0;
                color: green;
              }
        #showMoreComments{
            width: 200px;
            height: 30px;
            margin: 1%;
            margin-top: 2px;
            border: 0;
            border-radius: 5px;
            background-color: #000;
            color: #fff;
            font-size: 16px;
            font-family: sans-serif;
            cursor: pointer;
            position: absolute;
            Left: 20%;
        }
        #showMoreComments:hover{
            background: transparent;
            border: 2px solid blue;
            cursor: pointer;
            color: blue;
            box-shadow: 0 2px 8px #000;
        }
        .comment-box button{
            width: 200px;
            height: 30px;
            margin: 1%;
            margin-top: 2px;
            border: 0;
            border-radius: 5px;
            background-color: #071b30fa;
            color: #fff;
            font-family: sans-serif;
            font-size: 16px;
            cursor: pointer;
            position: absolute;
            Left: 20%;
        }
        .comment-box button:hover{
            background: transparent;
            border: 2px solid green;
            color: green;
            box-shadow: 0 2px 8px #000;
        }
        .comment-box textarea{
            border: 2px solid blue;
            width: 100%;
            font-family: sans-serif;
            background: transparent;
        }
    </style>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

</head>
<body>
       <?php
            if(isset($_SESSION["id"])){
                echo "<form class='comment-box' method='POST' action='".commentsOnLogin($conn)."'>
                <input type='hidden' name='UserName' value='".$_SESSION["username"]."'>
                <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
                <textarea name='message' required></textarea><br>
                <button id='cmntBtn' name='comment-submit'>comment</button><br><br>
            </form>";
            }
            else {
                echo "<form class='comment-box' method='POST' action='".setComments($conn)."'>
                <input type='hidden' name='UserName' value='Anonymous'>
                <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
                <textarea name='message' required></textarea><br>
                <button id='cmntBtn' name='comment-submit'>comment</button><br><br>
            </form>";
            }
       ?>
    <div id="comments">
        <?php
            $sql = "SELECT * FROM comments LIMIT 2";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result)>0){
                while($row = mysqli_fetch_assoc($result)){
                    echo "<p class='box'>";
                    echo "<label>".$row["uid"]."</label>";
                    echo "<p class='comment'>".$row["message"]."</p>";
                    echo "<p class='date'>".$row["date"]."</p><br>";
                    echo "</p>";
                    echo "<hr>";
                }

            }else{
                echo 'there are no comments';
            }
        ?>
    </div>
    <script>
       $(document).ready(function(){
           var commentCount = 2;
            $("#showMoreComments").click(function(){
                commentCount = commentCount + 2;
                $("#comments").load("load-comments.php", {
                    commentNewCount: commentCount
                }); 
            });
       });
   </script>
    <button id="showMoreComments">Show more comments</button>
</body>
</html>
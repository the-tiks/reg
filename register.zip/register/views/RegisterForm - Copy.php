﻿<?php session_start();
?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Register</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="300" > 
    <link rel="stylesheet" href="../styles/StyleSheet1.css" />
    <style>
        .input-error{
            box-shadow: 0 0 5px red;
            border-radius: 5px;
        }
        .form-message{
          
            margin-top: 5px;
        }
        .form-message .err-msg{
            color:  red;
        }
        .form-message .sucs-msg{
            color: green;
        }
        #bt:focus{
            outline:none;
        }
    </style>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
   <script>
       $(document).ready(function () {
          $(".Reg_Form").submit(function (event){
                event.preventDefault();
                var name = $("#nameId").val();
                var username = $("#usernameId").val();
                var email = $("#mailId").val();
                var password = $("#passwordId").val();
                var re_password = $("#confPwdId")
                var submit = $("#bt").val();

                $(".form-message").load("../scripts/php/check.php", {
                    name: name,
                    username: username,
                    email: email,
                    password: password,
                    re_password: re_password,
                    submit: submit
                });

          }); 
       });
   </script>
</head>
<body>
    <?php
    if(isset($_SESSION["id"]) || isset($_SESSION["empId"]) || isset($_SESSION["adminId"])){
        header("Location: home.php");
        exit();
    }
    else{
        echo'';

    }
    ?>
    <a href="LoginForm.php"><img src="https://img.icons8.com/color/48/000000/cancel.png" width="40px" height="40px"></a>
    <?php
            if(isset($_GET["error"])){
                if($_GET["error"] == "pwdNotMatch"){
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Passwords don't match!!!</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }
                elseif($_GET["error"]=="InvalidMail"){
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Invalid Email address</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }
                elseif($_GET["error"]=="emailExists"){
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Email already exists</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }
                elseif($_GET["error"]=="usernameExists"){
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Username is already taken</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }elseif ($_GET["error"]=="invalidname") {
                    echo'<p class="error-msg">Enter a valid name</p>';
                }
                elseif ($_GET["error"]=="shortuname") {
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>This username is too short</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }
                elseif ($_GET["error"]=="shortname") {
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Name is too short</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }elseif ($_GET["error"]=="shortpwd") {
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Password must be a minimum of 8 characters</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }elseif ($_GET["error"]=="mailError") {
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>".$mail->ErrorInfo."</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                    #echo $mail->ErrorInfo;
                }
            }elseif(isset($_GET["signup"])){
                if($_GET["signup"]=="success"){
                    echo"
                <div class='success_message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Account created successfully</p>
                    </div>
                </div>
                <script src='../scripts/js/success_messages.js'></script>";
                }
            }
        ?>
   
    <form class="Reg_Form" method="post"   action="../scripts/php/check.php">
        <h2>Sign Up</h2>
        <p class="form-message"></p>
        <hr>
        <label>Name:</label>
        <input type="text" id="nameId" name="name" placeholder="Enter your name"  required/>
        <label>Username:</label>
        <input type="text" id="usernameId" name="username" placeholder="Create a username" required/>
        <label>Email:</label>
        <input type="email" id="mailId" name="email" placeholder="Enter your email address" required/>
        <label>Password:</label>
        <input type="password" id="passwordId" name="password" placeholder="Enter your password" required/>
        <i class="fas fa-eye"></i>
        <label>Confrim Password:</label> 
        <input type="password" id="confPwdId" name="confirm_pwd" placeholder="Confirm password" required/>
        <i class="fas fa-eye"></i>
        <button type="submit" name="signUp" id="bt">Sign up</button>
        
   </form>
    

</body>
</html>

<main>
<div class="container">
      <div class="left-col">
      
       <h3>K9 Patrols</h3>
      <img  class="image" src="../images/k9-4.jpg" width="300px" height="300px">
      <a href="K9PatrolQuote.php"><button class="rqif" name="K9-pat">Request Information</button></a>

      </div>
      <div class="second-col">

      <h3>VIP Close Personnel Protection</h3>
      <img class="image" src="../images/vip.jpg"width="300px" height="300px">
      <a href="VIPQuote.php"><button class="rqif" name="VIP-protect">Request Information</button></a>

      </div>
      <div class="third-col">

      
      <h3>Armed Escort</h3>
      <img class="image" src="../images/amd2.jpg" width="300px" height="300px">
      <a href="ArmedEsQuote.php"><button class="rqif" name="Armed-Es">Request Information</button></a>

      </div>
      <div class="right-col">

      <h3>Physical Guarding</h3>
      <img class="image" src="../images/bdg.jpg" width="300px" height="300px">
      <a href="GuardQuote.php"><button class="rqif" name="Guard">Request Information</button></a>
                   
   </div>
</div>
   <div class="small_view">
      
      <h3>K9 Patrols</h3>
     <img  class="image" src="../images/k9-4.jpg" width="300px" height="300px">
     <a href="K9PatrolQuote.php"><br><button class="rqif" name="K9-pat">Request Information</button></a><br>

     <h3>Armed Escort</h3>
      <img class="image" src="../images/amd2.jpg" width="300px" height="300px">
      <a href="ArmedEsQuote.php"><br><button class="rqif" name="Armed-Es">Request Information</button></a><br>

     <h3>VIP Close Personnel Protection</h3>
     <img class="image" src="../images/vip.jpg"width="300px" height="300px">
     <a href="VIPQuote.php"><br><button class="rqif" name="VIP-protect">Request Information</button></a><br>

     <h3>Physical Guarding</h3>
      <img class="image" src="../images/bdg.jpg" width="300px" height="300px">
      <a href="GuardQuote.php"><br><button class="rqif" name="Guard">Request Information</button></a><br>

    
   </div>
</main>
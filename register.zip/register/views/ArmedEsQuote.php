<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Get quotation</title>
    <link rel="stylesheet" href="../styles/SentQuoteDesign.css">
</head>
    <body>
    <?php
        if(isset($_SESSION["id"])|| isset($_SESSION["empId"])){
        echo'';}
        else{
            header("Location:Homepage.php");
            exit();
        }

    ?>
        <a href="Services.php"><img src="https://img.icons8.com/ios/50/000000/backspace.png" 
        width="50px"
         height="40px"></a>
        <h2>p</h2>
        
        <form class="getQuote" method="post" action="../scripts/php/sendAEQuote.php">
            <?php
                if(isset($_GET['error'])){
                    if($_GET['error']=="emptyfields"){
                        echo"<p>Fill in all fields</p>";
                        exit();
                    }
                }elseif(isset($_GET['quote'])){
                    if($_GET['quote']=="success")
                    {
                        echo"<p>Check your email</p>";
                        exit();
                    }
                }
            ?>
            <img class="img-area" src="../images/amd2.jpg" width="150px" height="150px">
            <h1>Enter email to receive quotation</h1>
            <input type="email" name="email_id" placeholder="Enter your email address" required><br><br>
            <button type="submit" name="get-AE-quote-submit" >Get Quote</button><br><br>
            <a href="Services.php"><img src="https://img.icons8.com/color/48/000000/cancel.png" width="40px" height="40px"></a>
        </form>
    </body>
    </html>
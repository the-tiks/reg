<?php
	session_start();
	require '../scripts/php/comments.php';
?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>Baipushi Security Services</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="30" > 
	<link rel="stylesheet" type="text/css" href="../styles/homecss.css">
	
</head>
<body>
	<?php
		if(isset($_SESSION["id"])){
			if((time() - $_SESSION['last_login_timestamp']) > 900){
				header("Location: ../scripts/php/SesExpire.php");
				exit();
			}
			echo'';
		}
		elseif(isset($_SESSION["adminId"])){
			header("Location: AdminHome.phph");
			exit();
		}
		elseif(isset($_SESSION["empId"])){
			header("Location: EmpHome.php");
			exit();
		}
		else{
			header("Location: ../index.php");
			exit();
		}

		if(isset($_GET["signup"])){
			if ($_GET["signup"]=="success") {
				echo'<p class="success-msg">Account created successfully</p>';
			}
		}
	?>
	<header>
	<div class="wrapper">
         <div class="logo">
			<a href="home.php"><img src="../images/logo.png" width=200 height=70></a>
		</div>
    </div>
	<div class="navbar">
				<ul>
	<li><a>Profile</a>
		<ul>
			<li><a href="EditProfile.php" target="_blank">Edit Profile</a></li>
			<li><form class="bn" method="post" action="../scripts/php/ClearAcc.php"><input type="submit" name="delete-acc" value="Delete Account"></form></li>
			<li><form class="bn" method="post" action="../scripts/php/logout.php"><input type="submit" name="logout" value="Logout"></form></li>
		</ul>
	</li>
	<li><ul><a>Contact</a>
			<li><a href='contact_us.php'><i class="far fa-envelope"></i>Send an email</a></li>
			<li><a>Call us on (+27)87 630 0257</a></li>
		</ul>
	</li>
	<li><a>Invoices</a>
	</li>
	<li><a href="Services.php" >Services</a>
	</li>
	</ul>
			</div>
	</header>
	<div class="Content-area">
		
                <p class="description">Welcome to Baipushi Armed Security, a world class security company founded in 2014. Baipushi Armed Security employs approximately 
                    2000 employees and is ranked amongst the larger black privately owned security companies is South Africa.

                    Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                     tertiary, retail, freight, and banking sectors.

                    Baipushi Armed Security is a fully statutorily compliant business and 
                    accredited with the Private Security Industry Regulatory Authority.
                </p>
				<h1>p</h1>
				<hr>
			<div class="Cont">
				<div class="Left_Column">
					<h2>Where Are We Located</h2>
				</div>

				<div class="Mid_Column">
					<h2>Services</h2>
				<a href="Services.php" target="_blank"> <img src="../images/K9-4.jpg" width=150 height=150><p>We Offer K9 Patrol units to guard around homes, estates, 
					as well as Police force. Our Dogs are also trained to sniff out narcotics.</p></a>
                       <a href="Services.php" target="_blank"><img src="../images/vip.jpg" width=150 height=150><p>Our VIP Close Personnel Protection details offers a 
						   24 Hour VIP protection and escort at events or to serve as a protection detail.</p></a><br>
                       <a href="Services.php" target="_blank"><img src="../images/bdg.jpg" width=150 height=150><p>Our Body guarding detail offers a 24 hour protection and 
						   escort at events and private properties. Also includes 24 hour surveillance at private properties.</p></a>
                       <a href="Services.php" target="_blank"><img src="../images/amd2.jpg" width=150 height=150><p>Our Armred Escort services offers a 24 hour armred 
						   response and surveillance on private protection, events, and events with high profile people. We also offer Armred Escort 
						   to high profile people</p></a>
				</div>

				<div class="Right_Column">
					<h2>Reviews And Comments</h2>
					<?php
                       
					   echo" <form class='cmnt'method='post' action='".setComments($conn)."'>
					   <input type='hidden' name='uid' value='".getValue($conn)."'>
					   
					   <textarea name='message' required></textarea><br>
					   <button type='submit' name='Comment-submit'>Comment</button>
					   </form>";
					   echo" <div class='comment-box'>
					   			<p>'".getComments($conn)."'</p>
				   			</div>";
					   
					  
					   ?>
				</div>
			</div>
			
	<footer>
		
    <div class="container">
		<div class="left-col">
       		 <h3>Left col</h3>
		</div>

		<div class="second-col">
			<h3>Get in touch with us</h3>
			<a href="contact_us.php"><i class="far fa-envelope"></i>Send us an Email</a><br>
			<a hre="#"><i class="far fa-phone"></i>Call us on (+27)87 630 0257</a>
		</div>

		<div class="third-col">
				<h3>Get Quotation</h3>
				<a href="K9PatrolQuote.php">Get K9 Patrol Unit quotation</a><br>
				<a href="GuardQuote.php">Get Physical Guard service quotation</a><br>
				<a href="ArmedEsQuote.php">Get Our Armed Escort service quotation</a><br>
				<a href="VIPQuote.php">VIP Close Personnel Protection quotation</a>
		</div>

		<div class="right-col">
            <h3>Follow Us on</h3>
				<div class="icons">
					<a href="https://facebook.com" target="_blank"><img src="../images/fb-icon.jpg"
										width= "25px"
										height= "25px"></a><span></span>
					<a href="https://twitter.com" target="_blank"><img src="../images/twtr-icon.jpg"
										width= "25px" 
										height= "25px"></a><span></span>
					<a href="https://instagram.com" target="_blank"><img src="../images/ig-icon.jpg"
										width= "25px"
										height= "25px"></a>

				</div>
		</div>
	</div>
</footer>
	</div>
</body>
</html>

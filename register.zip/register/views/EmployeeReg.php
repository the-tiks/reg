<?php
session_start();
?>
<html>
<head>
    <meta charset="utf-8" />
    <title>Create Profile</title> 
    <link rel="stylesheet" href="../styles/StyleSheet1.css" />
</head>
<body>
    <?php
        if(isset($_SESSION["id"]) || isset($_SESSION["adminId"]) || isset($_SESSION["empId"])){
            header("Location: Homepage.php");
            exit();
        }
        else {
            echo'';
        }
    ?>
   
 <div class="Login_Form">
    <form method="post" action="../scripts/php/CreateProfile.php">
        <div class="img-area">
            <img src="../images/best.png" alt="" />
        </div>
        <h2>Create Profile</h2>
        <?php
        if(isset($_GET["error"])){
            if($_GET["error"] == "pwdMismatch"){
                echo"<p>Passwords don't match!!";
                
            }elseif($_GET["error"] == "emptyfields"){
                echo"<p>Fill in all fields!!";
                
            }elseif($_GET["error"] == "unabletoconnect"){
                echo"<p>An unknown error occurred</p>";
            
            }
            elseif($_GET["error"] == "invalidMail"){
                echo"<p>Invalid email address</p>";
                
            }elseif($_GET["error"] == "emailtaken"){
                echo"<p>Email already exits</p>";
                
            }
        }elseif(isset($_GET["Signup"])){
            if($_GET["Signup"]=="Success"){
                echo"<p>You have successfully created your account!";
                
            }
        }
        ?>
         <p>Email:</p>
        <input type="email" name="email" placeholder="Enter your email" required/>
        <p>Password:</p>
        <input type="password" name="pwd" placeholder="Enter your password" required/>
        <p>Confirm Password:</p>
        <input type="password" name="pwd-repeat" placeholder="Confirm password" required/>
        <input type="submit" name ="submit "value="Create Profile" />
    </form>
</div>
</body>
</html>
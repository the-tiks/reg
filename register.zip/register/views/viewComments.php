<?php
require '../scripts/php/comments.php';
date_default_timezone_set('Africa/Johannesburg');
                       
                       echo" <style text='css/stylesheet'>
                       textarea{
                        width: 100%;
                        height: 50px;
                        font-family: inherit;
                        border: 2px solid #0476aa;
                    }
                    textarea:focus{
                        outline: #22d336;
                        border: 2px solid #22d336;
                    }
                    #cmntBtn{
                        background: #0476aa;
                        color: #fff;
                        height: 30px;
                        margin-top: 10px;
                        margin-left: 15%;
                        width: 75%;
                        border: 0;
                        border-radius: 5px;
                        cursor: pointer;
                        text-transform: uppercase;
                      }
                      #cmntBtn:hover{
                        background: #22d336;
                        color: #fff;
                        transition: 0.5s;
                        cursor: pointer;
                      }
                       </style><form class='cmnt'method='post' action='".setComments($conn)."'>
                        <input type='hidden' name='uid' value='Anonymous'>
                        <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
                        <textarea name='message' required></textarea><br>
                        <button type='submit' id='cmntBtn' name='Comment-submit'>Comment</button>

                        </form>";
                        echo"<style text='css/stylesheet'>
                        .comment-box{
                            width: 100%;
                            
                        }
                        p{
                            color: green;
                            font-family: sans-serif;
                        }
                        label{
                            font-family: sans-serif;
                        }
                        .comment-box .dte{
                            color: #000;
                        }
                        </style>
                        <div class='comment-box'>
                            <p>".getComments($conn)."</p>
                        </div>";
                        
                       
                        ?>
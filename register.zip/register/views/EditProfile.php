<?php
    session_start();
    include '../scripts/php/UpdateDetails.php';
?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>Profile</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="300" > 
	<link rel="stylesheet" type="text/css" href="../styles/EditPro.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
    <?php
        if(isset($_SESSION["id"])){
            echo'';
        }
        else {
            header("Location: home.php");
            exit();
        }
    ?>
    <header>
    <span>
            <a href="Homepage.php"><img src="https://img.icons8.com/ios/50/000000/backspace.png" 
                width="50px"
                height="40px"></a></span>
       <span> <h1>Profile</h1></span>
    </header>
    <main>
        <div class="content-area">
            <?php
               if(isset($_GET["error"])){
                if($_GET["error"]=="invalidName"){
                    echo'<p class="error-msg">Enter a valid name</p>';
                }
                elseif ($_GET["error"]=="Shortname") {
                    echo'<p class="error-msg">Name is too short</p>';
                }
                elseif ($_GET["error"]=="sql") {
                    echo'<p class="error-msg">An unknown error has occurred</p>';
                    exit();
                }
                elseif ($_GET["error"] == "mailexists") {
                    echo'<p class="error-msg">This email already exists</p>';
                }
            }
            elseif (isset($_GET["change"])) {
                if ($_GET["change"]=="success") {
                    echo"
                <div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Profile updated successfully</p>
                    </div>
                </div>
                <script src='../scripts/js/error_messages.js'></script>";
                }
            }
            ?>
    <?php
            echo "".getProfile($conn)."";
        ?>
        </div>
        </main>
   
</body>
</hmtl>
﻿<?php

    session_start();
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/PHPMailer/src/Exception.php';
require '../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../PHPMailer/PHPMailer/src/SMTP.php';
require '../scripts/php/db_conn.php';

if(isset($_POST['email_address'])){
    $emailTo = $_POST['email_address'];

    if(empty($emailTo)){
        header("Loaction:ResetPassword.php?error=emptyfields");
        exit();
    }elseif(!filter_var($emailTo,FILTER_VALIDATE_EMAIL)){
        header("Location:ResetPassword.php?error=invalidmail");
        exit();
    }else{
        $code = uniqid(true);
        $sql1= "INSERT INTO resetpassword(code, email) VALUES ('$code','$emailTo')";
        $query = mysqli_query($conn,$sql1);
        if(!$query){
            echo("Error");
        }
    
        // Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);
    
    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('mathikithelatc@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        $url="http://". $_SERVER["HTTP_HOST"].dirname($_SERVER["PHP_SELF"])."../scripts/ResetPassword.php?code=$code";
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Your password reset link';
        $mail->Body    = "<h1>You requested a password reset</h1>
                            click <a href='$url'>this link</a> to do so";
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        
    
       
        if( $mail->send()){
            header("Location:ResetPass.php?signup=success");
            exit();
        }else{
            header("Location:ResetPass.php?error=failed".$mail->ErrorInfo);
            exit();
        }
        
    } catch (Exception $e) {
        echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }

    }

   
    
exit();
}

?>
<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Password Reset</title>
    <link rel="stylesheet" href="../styles/StyleSheet1.css" />
</head>
<body>
    <?php
        if(isset($_SESSION["id"]) || isset($_SESSION["empId"]) || isset($_SESSION["adminId"])){
            header("Location: home.php");
            exit();
        }
        else{
            echo'';
        }
    ?>
    <div class="ResetPass-Form">
    <form method="POST" action="ResetPass.php">
    <?php
        if(isset($_GET["error"])){
            if($_GET["error"]=="invalidmail"){
                echo"<p>This email is invalid</p>";
            }
            
            elseif($_GET["error"]=="failed"){
                echo $mail->ErrorInfo;
            }
            
        }
        elseif(isset($_GET["signup"])){
            if($_GET["signup"]=="success"){
                echo"<p>A reset password link has been sent to your email";
            }
           
        }
    ?>
        
        <h2>Password Reset</h2>
        <hr>
        <label>Email:</label>
        <input type="email" name="email_address" placeholder="Enter your email" required />
        <button type="submit" name="reset-pass_submit" id="bt">Submit</button><br><br>
        <a href="LoginForm.php"><img src="https://img.icons8.com/color/48/000000/cancel.png" width="40px" height="40px"></a>
        </form>
    </div>

</body>
</html>

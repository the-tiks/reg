<?php
    if (isset($_POST["submit"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];

        $errorEmpty = false;
        $errorEmail = false;

        if(empty($email) || empty($password)){
            echo "<span>Fill in all fields</span>";
            $errorEmpty = true;
        }

        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<span>Invalid email address</span>";
            $errorEmail = true;
        }

        else{
            echo "<span>Account registered successfully</span>";

        }
    }
    else{
        echo "error 404!!!";
    }
?>

<script>
    $("#mailId, #pwdId").removeClass("input-error");
    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorEmail = "<?php echo $errorEmail; ?>";

    if (errorEmpty == true) {
        $("#mailId, #pwdId").addClass("input-error");
    }

    if (errorEmail == true) {
        $("#mailId").addClass("input-error");
    }

    if(errorEmpty == false && errorEmail == false){
        $("#mailId, #pwdId").val("");
    }
</script>
<?php
    session_start();
    require './scripts/php/comments.php';
    date_default_timezone_set('Africa/Johannesburg');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles/new.css">
    <link rel="shortcut icon" type="img/jpg" href="./images/amd2.jpg">
    <meta http-equiv="refresh" content="500" > 
    <title>Baipushi Security Services</title>
    
</head>
<body>
    
        <div class="backdrop"></div>
        <header class="main-header">
            <button id="side-menu-toggle">Menu</button>
            <div class="logo">
                    <a href="#"><img src="./images/logo.png" height=55 width=300></a>
                </div>
            <nav class="main-header__nav">
                <ul class="main-header__item-list">
                    <li class="main-header__item">
                        <a  href="#">Shop</a>
                    </li>
                    <li class="main-header__item">
                        <a  href="#">Products</a>
                    </li>
                    <li class="main-header__item">
                        <a href="#">Cart</a>
                    </li>
                    <li class="main-header__item">
                        <a href="#">Orders</a>
                    </li>
                    <li class="main-header__item">
                        <a href="./views/Services.php">Services
                        </a>
                    </li>
                    <li class="main-header__item">
                        <button id="loginBtn"> Login</button>
                        <script>
                            document.getElementById("loginBtn").addEventListener("click", function(){
                                document.querySelector(".popup").style.display = "flex";
                                document.querySelector(".description").style.display = "none";
                                //document.querySelector(".popup").style.display = "none";
    
                            })
                        </script>
                    </li>
                </ul>
            </nav>
        </header>

        <nav class="mobile-nav">
            <ul class="mobile-nav__item-list">
                    <li class="mobile-nav__item">
                        <a  href="#">Shop</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="#">Products</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="#">Cart</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="#">Orders</a>
                    </li>
                    <li class="mobile-nav__item">
                        <a  href="./views/Services.php">Services
                        </a>
                    </li>
                    <li class="mobile-nav__item">
                        <button id="Btn" >Login</button>
                        <script>
                            document.getElementById("Btn").addEventListener("click", function(){
                                document.querySelector(".popup").style.display = "flex";
                                document.querySelector(".description").style.display = "none";
                                document.querySelector(".mobile-nav").style.display = "none";
                                document.querySelector(".backdrop").style.display = "none";
                                //document.querySelector(".popup").style.display = "none";
    
                            })
                        </script>
                    </li>
                </ul>
            </nav>
            <script src="./scripts/js/main.js"></script>
            <div class="container">
                <h1>Popup login</h1>
                <a href="#" id="button" class="button">Login</a>
            </div>
            
            <div class="popup">
                <div class="popup-content">
                    <button id="close" class="close">x</button>
                    <script>
                        document.getElementById("close").addEventListener("click", function () {
                        document.querySelector(".popup").style.display = "none";
                        document.querySelector(".description").style.display = "block";
                        
                        document.querySelector(".mobile-nav").style.display = "flex";
                        document.querySelector(".backdrop").style.display = "flex";
                        })

                    </script>
                    <h1>Login</h1>
                    <?php
                        if(isset($_GET["error"])){
                            if($_GET["error"] == "WrongDetails"){
                                echo '<p class="error-msg">Incorrect email or password!!!</p>';
                            }
                        }
                    ?>
                    <hr>
                    <form method="POST" action="./scripts/php/UserLogin.php">
                        <label >Email:</label>
                        <input type="email" name="email" placeholder="Email" required>
                        <label>Password:</label>
                        <input type="password" name="pwd" placeholder="Password" required>
                        <button type="submit" name="login-submit" id="login-submit">Login</button>
                    </form>
                    <a href="#" class="reset"><button id="reset">Forgot Password?</button></a>
                    <script>
                        document.getElementById("reset").addEventListener("click", function(){
                            document.querySelector(".resetPass-popup").style.display = "flex";
                            document.querySelector(".description").style.display = "none";
                            document.querySelector(".popup").style.display = "none";

                        })
                    </script>
                    <a href="#" class="register"><button id="register">Don't have an account? Signup here?</button></a>
                    <script>
                        document.getElementById("register").addEventListener("click", function(){
                        document.querySelector(".regForm-popup").style.display = "flex";
                        document.querySelector(".description").style.display = "none";
                        document.querySelector(".popup").style.display = "none";
                        })

                    </script>
                </div>
            </div>
           
            <div class="regForm-popup">
                <div class="Reg_Form">
                    <button id="closeReg" class="close">x</button>
                    <script>
                        document.getElementById("closeReg").addEventListener("click", function () {
                        document.querySelector(".regForm-popup").style.display = "none";
                        document.querySelector(".description").style.display = "block";
                        document.querySelector(".mobile-nav").style.display = "flex";
                        document.querySelector(".backdrop").style.display = "flex";
                        })

                    </script>
                    <button id="RegBack" class="RegBack"><</button>
                    <script>
                        document.getElementById("RegBack").addEventListener("click", function () {
                        document.querySelector(".regForm-popup").style.display = "none";
                        document.querySelector(".description").style.display = "none";
                        document.querySelector(".popup").style.display = "flex";
                        })

                    </script>
                    <?php
                    if(isset($_GET["error"])){
                        if($_GET["error"] == "pwdNotMatch"){
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Passwords don't match!!!</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }
                        elseif($_GET["error"]=="InvalidMail"){
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Invalid Email address</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }
                        elseif($_GET["error"]=="emailExists"){
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Email already exists</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }
                        elseif($_GET["error"]=="usernameExists"){
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Username is already taken</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }elseif ($_GET["error"]=="invalidname") {
                            echo'<p class="error-msg">Enter a valid name</p>';
                        }
                        elseif ($_GET["error"]=="shortuname") {
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>This username is too short</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }
                        elseif ($_GET["error"]=="shortname") {
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Name is too short</p>
                            </div>
                        </div>
                        <script src='../scripts/js/error_messages.js'></script>";
                        }elseif ($_GET["error"]=="shortpwd") {
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Password must be a minimum of 8 characters</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                        }elseif ($_GET["error"]=="mailError") {
                            echo"
                        <div class='message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>".$mail->ErrorInfo."</p>
                            </div>
                        </div>
                        <script src='./scripts/js/error_messages.js'></script>";
                            #echo $mail->ErrorInfo;
                        }
                    }elseif(isset($_GET["signup"])){
                        if($_GET["signup"]=="success"){
                            echo"
                        <div class='success_message-popup'>
                            <div class='box'>
                                <div class='close'>&times;</div>
                                <p>Account created successfully</p>
                            </div>
                        </div>
                        <script src='./scripts/js/success_messages.js'></script>";
                        }
                    }
                    ?>

                    <form method="post"   action="./scripts/php/checkUser.php">
                        <h2>Sign Up</h2>
                        <hr>
                        <label>Name:</label>
                        <input type="text" name="fname" placeholder="Enter your name"  required/>
                        <label>Username:</label>
                        <input type="text" name="Username" placeholder="Create a username" required/>
                        <label>Email:</label>
                        <input type="email" name="email_address" placeholder="Enter your email address" required/>
                        <label>Password:</label>
                        <input type="password" name="pwd" placeholder="Enter your password" required/>
                        <label>Confrim Password:</label> 
                        <input type="password" name="confirm_pwd" placeholder="Confirm password" required/>
                        <button type="submit" name="signUp" id="login-submit">Sign up</button>     
                   </form>
                </div>
            </div>
           <div class="resetPass-popup">
            <div class="ResetPass-Form">
                <button id="closeReset" class="close">x</button>
                <script>
                    document.getElementById("closeReset").addEventListener("click", function(){
                        document.querySelector(".resetPass-popup").style.display = "none";
                        document.querySelector(".description").style.display = "block";
                        document.querySelector(".mobile-nav").style.display = "flex";
                        document.querySelector(".backdrop").style.display = "flex";
                    })
                </script>
                <button id="ResBack" class="ResBack"><</button>
                <script>
                    document.getElementById("ResBack").addEventListener("click", function(){
                    document.querySelector(".resetPass-popup").style.display = "none";
                    document.querySelector(".description").style.display = "none";
                    document.querySelector(".popup").style.display = "flex";
                    })
                </script>
                <form method="POST" action="./scripts/php/ResetUserPass.php">
                    <h2>Password Reset</h2>
                    <hr>
                    <label>Email:</label>
                    <input type="email" name="email_address" placeholder="Enter your email" required />
                    <button type="submit" name="reset-pass_submit" id="login-submit">Submit</button>
                    </form>
                </div>
           </div>

           <div class="description">
                        <h1>About Us</h1>
                    <p class="fullScreenDescription">Welcome to Baipushi Armed Security, a world class security company founded in 2014. Baipushi Armed Security employs approximately 
                        2000 employees and is ranked amongst the larger black privately owned security companies is South Africa.

                        Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.

                    </p>
                    
                </div>

    <div class="cont">
        <div class="smallScreen">
                <div class="left">
                    <label>Image 1</label>
                    <img src="./images/vip.jpg" width="100%"><br>
                    <label>Image 1</label>
                    <img src="./images/vip.jpg" width="100%"><br>
                    <label>Image 1</label>
                    <img src="./images/vip.jpg" width="100%"><br>
                    <label>Image 1</label>
                    <img src="./images/vip.jpg" width="100%">
                </div>
                <div class="right">
                    <div class="desp">
                    <label>Image 1</label>  
                    <p>Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.</p><br>
                        <button >Request Information</button>
                    </div>

                    <div class="desp">
                    <label>Image 1</label>   
                    <p>Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.</p><br>
                        <button >Request Information</button>
                    </div>

                    <div class="desp">
                    <label>Image 1</label>   
                    <p>Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.</p><br>
                        <button >Request Information</button>
                    </div>

                    <div class="desp">
                    <label>Image 1</label>   
                    <p>Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.</p><br>
                        <button >Request Information</button>
                    </div>
                </div>
        </div>

        <div class="left-column">
            <h1>Left column</h1>
        </div>
        <div class="middle-column">
            <h1>Middle column</h1>
            <div class="stuff">
                <div class="first-two">
                    <a><img src="./images/amd2.jpg" width="24%"><p>Hey there</p></a>
                    <a><img src="./images/amd2.jpg" width="24%"><p>Hey thgjryjujrjjjjjjjjytuytghejrliulllllllllllllllllktynbtrgfere</p></a>
                    <a><img src="./images/amd2.jpg" width="24%"><p>Hey there</p></a>
                    <a><img src="./images/amd2.jpg" width="24%"><p>Hey therdxfgfchhhhhhhhhhhhhhhhhhhxdfvcxdgfxfdhzcxnsfhe</p></a>
                </div>
                <div class="last-two">
                    <img src="./images/vip.jpg" width="24%">
                    <img src="./images/vip.jpg" width="24%">
                    <img src="./images/vip.jpg" width="24%">
                    <img src="./images/vip.jpg" width="24%">
                </div>
            </div>
            
        </div>
        <div class="right-column">
            <div class='cmtArea'>
                <h3>Reviews And Comments</h3>
                  <iframe with=100% height=90% src='./views/comments.php' frameborder=0></iframe>
                </div>
        </div><br>
    </div>
    
</body>
<footer>
    <div class="ground">
        <div class="col-1">
           <h3>Where Are We Located</h3>
           <P>Hello jfvvjhf</P>
       </div>
       <div class="col-2">
       <h3>Get in touch with us</h3>
       <a href="./Views/contact_us.php"><i class="far fa-envelope"></i>Send us an Email</a><br>
       <p><i class="far fa-phone"></i>Call us on (+27)87 630 0257</p>
       </div>
       <div class="col-3">
       <h3>Get Quotation</h3>
           <a href="./Views/LoginForm.php">Get K9 Patrol Unit quotation</a><br>
           <a href="./Views/LoginForm.php">Get Physical Guard service quotation</a><br>
           <a href="./Views/LoginForm.php">Get Our Armed Escort service quotation</a><br>
           <a href="./Views/LoginForm.php">VIP Close Personnel Protection quotation</a>
       </div>
           <div class="col-4">
                 <h3>Follow us</h3>
                   <div class="icons">
                   <a href="https://facebook.com"><img src="./images/fb-icon.jpg"
                                       width= "25px"
                                       height= "25px"></a><span></span>
                   <a href="https://twitter.com"><img src="./images/twtr-icon.jpg"
                                       width= "25px"
                                       height= "25px"></a><span></span>
                   <a href="https://instagram.com"><img src="./images/ig-icon.jpg"
                                       width= "25px"
                                       height= "25px"></a>

            </div>
       </div>
</footer>

</html>
-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2021 at 11:04 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `uid`, `date`, `message`) VALUES
(1, 'Anonymous', '2021-03-10 11:12:58', 'sresredsdfsr'),
(2, 'Anonymous', '2021-03-10 11:13:31', 'setfghuitdr txugj'),
(3, 'Toni45', '2021-03-10 13:02:54', 'love it'),
(4, 'Anonymous', '2021-03-17 20:09:11', 'Welcome to Baipushi Armed Security, a world class security company founded in 2014. Baipushi Armed Security employs approximately 2000 employees and is ranked amongst the larger black privately owned security companies is South Africa. Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial, tertiary, retail, freight, and banking sectors. Baipushi Armed Security is a fully statutorily compliant business and accredited with the Private Security Industry Regulatory Authority.');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(10) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_lastname` varchar(255) NOT NULL,
  `emp_email` varchar(255) NOT NULL,
  `emp_position` varchar(255) NOT NULL,
  `emp_salary` decimal(65,0) NOT NULL,
  `emp_num` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `emp_lastname`, `emp_email`, `emp_position`, `emp_salary`, `emp_num`) VALUES
(1, 'wade', 'barrel', 'mathikithelatc@gmail.com', 'cleaner', '1250', 76028832),
(2, 'wade', 'barrel', 'mathikithelatmc@gmail.com', 'cleaner', '1250', 76028832),
(3, 'Jack', 'Mah', 'jack@gmail.com', 'manager', '15000', 2147483647),
(4, 'max', 'field', 'max@gmail.com', 'pa', '4000', 1234567896),
(5, 'max', 'field', 'ma@gmail.com', 'pa', '4000', 1234567896);

-- --------------------------------------------------------

--
-- Table structure for table `emp_login`
--

CREATE TABLE `emp_login` (
  `id` int(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_login`
--

INSERT INTO `emp_login` (`id`, `email`, `password`) VALUES
(1, 'mathikithelatc@gmail.com', '$2y$10$sIreWuey6nJT9rQmg.bKYOSYYDmqSBaNdYwiRvpfj9TPozWrX9oPW'),
(2, 'mathikithela@gmail.com', '$2y$10$1hxr1AuqgOgtqI6sgtnSOewbZX/AtWkQdikL1jDZPoW63R35ri0tW'),
(3, 'math@gmail.com', '$2y$10$/OJBW0Z8pQSdFNess58kgOp8hdKKLl4reK.VhBoEP0y04VhXh1fpW');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `no` int(10) NOT NULL,
  `service` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `issued_by` varchar(255) NOT NULL,
  `emp_id` int(10) DEFAULT NULL,
  `InvoiceDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`no`, `service`, `duration`, `date`, `cost`, `customer_email`, `issued_by`, `emp_id`, `InvoiceDate`) VALUES
(3, 'K9 Unit', '10 Days', '2021-03-17', '15 000', 'mathikithelatc@gmail.com', 'wade barrel', 1, '2021-03-19 17:02:57'),
(4, 'Armed Response', '5 days', '2021-03-10', '12 000', 'tonimack.ul@gmail.com', 'wade barrel', 1, '2021-03-19 17:15:08'),
(5, 'hgjjh', '15 hours', '2021-03-10', '55555', 'tonimack.ul@gmail.com', 'Employee', 1, '2021-03-19 17:30:13'),
(6, 'fyvdbrvdhvdfv', '5 days ', '2021-03-01', '15 258', 'tonimack.ul@gmail.com', 'wade barrel', 1, '2021-03-19 17:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `incoming_msg_id` int(255) NOT NULL,
  `outgoing_msg_id` int(255) NOT NULL,
  `msg` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profileimg`
--

CREATE TABLE `profileimg` (
  `id` int(10) NOT NULL,
  `userid` int(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

CREATE TABLE `resetpassword` (
  `id` int(10) NOT NULL,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `response`
--

CREATE TABLE `response` (
  `id` int(10) NOT NULL,
  `message` varchar(1500) NOT NULL,
  `responder` varchar(255) NOT NULL,
  `recepient` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `email`, `password`) VALUES
(111227, 'Robert', 'Admin', 'admin@gmail.com', 'e1f055458e3ca7f7a898'),
(111234, 'tebogo', 'theticks123', 'mathikithelatc@gmail.com', '$2y$10$2qPAUhb5i8mg5q.yh6BPrOWh2BBsxNCrREWfmjIvVOn67VN.1S0UO'),
(111235, 'Toni', 'Toni45', 'mat.ul@gmail.com', '$2y$10$pH4epU8fAeXUVC1qREvIsu5Q/a2x4rN.Df56i42BnhveqkjgtsFm.'),
(111236, 'Tebogo', 'Tik', 'tonimack.ul@gmail.com', '$2y$10$CQJN3CEzzWT.dmfPMOW8QOC5N4KS12pkaich06RoB1dx49oHU9KoC'),
(111237, 'xbxfgbfgbf', 'dhdfhgh', 'shfghsh@gmail.com', '$2y$10$wSksAF/AJwX2VDm9m0PHX.JKXNf630vcoJrtlHQ3wdepCWdr1wlqW');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `unique_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `validate`
--

CREATE TABLE `validate` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `emp_login`
--
ALTER TABLE `emp_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `profileimg`
--
ALTER TABLE `profileimg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resetpassword`
--
ALTER TABLE `resetpassword`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `response`
--
ALTER TABLE `response`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `validate`
--
ALTER TABLE `validate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `emp_login`
--
ALTER TABLE `emp_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profileimg`
--
ALTER TABLE `profileimg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resetpassword`
--
ALTER TABLE `resetpassword`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `response`
--
ALTER TABLE `response`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111238;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `validate`
--
ALTER TABLE `validate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

  const MessagePopup = document.querySelector(".message-popup");
  const close = document.querySelector(".close");


  window.addEventListener("load",function(){
 
   showPopup();
   // setTimeout(function(){
   //   loginPopup.classList.add("show");
   // },5000)
   removePopup();

  })

  function showPopup(){
        const timeLimit = 1// seconds;
        let i=0;
        const timer = setInterval(function(){
         i++;
         if(i == timeLimit){
          clearInterval(timer);
          MessagePopup.classList.add("show");
         } 
         console.log(i)
        },1000);
  }


  close.addEventListener("click",function(){
MessagePopup.classList.remove("show");
  })

  function removePopup(){
      const timeLimit = 10 //10 seconds;
      let i=0;
      const timer = setInterval(function(){
          i++;
          if(i == timeLimit){
              clearInterval(timer);
              MessagePopup.classList.remove("show");
          }
          console.log(i);
      }, 1000)
  }

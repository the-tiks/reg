document.getElementById("button").addEventListener("click", function(){
    document.querySelector(".popup").style.display = "flex";
})

document.getElementById("close").addEventListener("click", function () {
    document.querySelector(".popup").style.display = "none";
})

document.getElementById("loginBtn").addEventListener("click", function(){
    document.querySelector(".popup").style.display = "flex";
})


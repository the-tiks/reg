<?php
require 'db_conn.php';

if(isset($_POST["deleteRecord-submit"])){
    $mailId = $_POST["mailId"];
    if(!filter_var($mailId, FILTER_VALIDATE_EMAIL)){
        header("Location: ../Views/AdminHome.php?error=InvalidEmail");
        exit();
    }
    else{
        $sql = "SELECT * FROM employees WHERE emp_email='$mailId'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result)>0){
            $qry = "DELETE FROM employees WHERE emp_email='$mailId'";
            $res = mysqli_query($conn, $qry);
            if($res){
                $qry1 ="DELETE FROM emp_login WHERE email='$mailId'";
                $res1 = mysqli_query($conn, $qry1);
                if($res1){
                    header("Location: ../Views/AdminHome.php?clear=success");
                    exit();
                }
                else {
                    header("Location; ../Views/AdminHome.php?error=sqlerr");
                    exit();
                }
            }
            else {
                echo"Unknown error has occurred";
            }
            
        }else{
            header("Location: ../Views/AdminHome.php?error=MailDntExist");
            exit();
        }
    }
}

elseif (isset($_POST["UpdateRecord-submit"])) {
    $EmailId = $_POST["EmailId"];
    if(!filter_var($EmailId, FILTER_VALIDATE_EMAIL)){
        header("Location: ../Views/AdminHome.php?error=InvalidEmail");
        exit();
    }
    else {
        function getEmployeeDetails($conn){
            $Query = "SELECT * FROM employees WHERE emp_email='$EmailId'";
            $rs = mysqli_query($conn,$Query);
            $row=$rs->fetch_assoc();
            if(mysqli_num_rows($rs)>0){
                echo"
                <div form class='res' method='post' action='updateEmp'>
                <input type='text' name='newName' value='".$row["emp_name"]."'>
                <input type='text' name='newLastame' value='".$row["emp_lastname"]."'>
                <input type='email' name='newMail' value='".$row["emp_email"]."'>
                <input type='text' name='newPostion' value='".$row["emp_position"]."'>
                <input type='text' name='newSalary' value='".$row["emp_salary"]."'>
                <input type='text' name='newNumber' value='".$row["emp_num"]."'>
                </div>
                ";
            }
            else {
                header("Location: ../Views/AdminHome.php?error=empnotfound");
                exit();
            }
        }
    }
}
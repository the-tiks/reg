<?php
session_start();
include "db_conn.php";

if(isset($_POST["email"])){

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
     }

    $email = validate($_POST['email']);
    $password = validate($_POST['pwd']);
    $confirm_pwd = validate($_POST['pwd-repeat']);
     if(empty($email) || empty($password) || empty($confirm_pwd)){
         header("Location: ../../views/EmployeeReg.php?error=emptyfields");
         exit();

     }
     elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        header("Location: ../../views/EmployeeReg.php?error=invalidMail");
        exit();
    }
    elseif($password !== $confirm_pwd){
        header("Location: ../../views/EmployeeReg.php?error=pwdMismatch");
        exit();
    }else{
        $sql= "SELECT * FROM emp_login WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
    
        if(mysqli_num_rows($result)>0){
            header("Location: ../../views/EmployeeReg.php?error=emailtaken".$email);
            exit();
        }else{
            $hashedPwd=password_hash($password,PASSWORD_DEFAULT);
            $sql="INSERT INTO emp_login (email,password) VALUES ('$email','$hashedPwd')";
            $res = mysqli_query($conn,$sql);
            if($res){
                header("Location: ../../views/LoginForm.php?Signup=Success");
                exit();
                
            }else{
                echo"Unable to connect";
                exit();
            }
        }

    }
   
}else{
    header("Location: ../../views/EmployeeReg.php?error=unabletoconnect");
    exit();
}
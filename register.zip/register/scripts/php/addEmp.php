<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/PHPMailer/src/Exception.php';
require '../../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/PHPMailer/src/SMTP.php';
include "db_conn.php";

if(isset($_POST["regUser"])){

    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
     }

    $E_name = validate($_POST['name']);
	$E_Lname = validate($_POST['Lastname']);
	$email = validate($_POST['email_ad']);
	$E_Pos = validate($_POST['Pos']);
    $E_Sal= validate($_POST['Salary']);
    $E_Num = validate($_POST['ContactNum']);
    $UserData ='name='.$E_name.'Lastname='.$E_Lname.'email_ad='.$email;
    if(empty($E_name) || empty($E_Lname) || empty($email) || empty($E_Pos) || empty($E_Sal) || empty($E_Num)){
        header("Location: ../../views/AdminHome.php?error=emptyfields".$UserData);
        exit();

    }
    elseif(strlen($E_name)<2){
        header("Location: ../../views/AddEmployees.php?error=shortName".$UserData);
        exit();
    }
    elseif(strlen($E_Lname)<2){
        header("Location: ../../views/AdminHome.php?error=shortLastName".$UserData);
        exit();
    }
    elseif (!preg_match("/^[a-zA-Z]+$/",$E_name)) {
        header("Location: ../../views/AdminHome.php?error=invalidName".$UserData);
        exit();
    }
    elseif (!preg_match("/^[a-zA-Z]+$/",$E_Lname)) {
        header("Loaction: ../../views/AdminHome.php?error=invalidLastName".$UserData);
        exit();
    }
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        header("Location: ../../views/AdminHome.php?error=invalidmail".$UserData);
        exit();

    }
    elseif(!preg_match("/^[0-9]+$/",$E_Num)){
		header("Location: ../../views/AdminHome.php?error=invalidNumber".$UserData);
		exit();
    }
    elseif(strlen($E_Num)<10){
		header("Location: ../../views/AdminHome.php?error=shortNumber".$UserData);
		exit();
	}  elseif(strlen($E_Num)>10){
		header("Location: ../../views/AdminHome.php?error=bigNumber".$UserData);
		exit();
	}
    else{

        $sql= "SELECT * FROM employees WHERE emp_email=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s',$email);
         $result = $stmt->execute();

    if(mysqli_num_rows($result)>0){
        header("Location: ../../views/AdminHome.php?error=emailtaken".$UserData);
        exit();
    }
    $sql1= "SELECT * FROM employees WHERE emp_num=?";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param('s',$E_Num);
    //$stmt->execute();
    $result1 = $stmt1->execute();
    if(mysqli_num_rows($result1)){
      header("Loaction: ../../views/AdminHome.php?error=numbertaken".$UserData);
      exit();  
    }
    else{
        $sql="INSERT INTO employees (emp_name, emp_lastname, emp_email, emp_position, emp_salary, emp_num) 
        VALUES (?, ?, ?, ?, ?)";
         $stmt3 = $conn->prepare($sql);
         $stmt3->bind_param('ssssss',$E_name,$E_Lname,$email,$E_Pos,$E_Sal,$E_Num);
        $res =$stmt3->execute();
        if($res){

            $email = validate($_POST['email_ad']);
             // Instantiation and passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {
                //Server settings
                                    // Enable verbose debug output
                $mail->isSMTP();                                            // Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
                $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
                $mail->Password   = 'y@m1n@@UL';                               // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            
                //Recipients
                $mail->setFrom('tonimack.ul@gmail.com', 'Bapushi');
                $mail->addAddress("$email");     // Add a recipient               
                $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
            
            
            
                // Content
                $url="http://". $_SERVER["HTTP_HOST"].dirname($_SERVER["PHP_SELF"])."../Views/EmployeeReg.php?";
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Account Creation link';
                $mail->Body    = "<h1>Use this link to create your login details</h1>
                                    click <a href='$url'>this link</a> to do so ";
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
                
            
               
                if( $mail->send()){
                    header("Location: ../../views/AdminHome.php?signup=Success".$UserData);
                     exit();
                }else{
                    header("Location: ../../views/AdminHome.php?error=failed".$mail->ErrorInfo);
                    exit();
                }
                
            } catch (Exception $e) {
                echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
            }  
            
        }else{
            echo"Unable to connect";
        }
    }

    }

    
}else{
    header("Location: ../../views/home.php");
    exit();
}
<?php 
session_start(); 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/PHPMailer/src/Exception.php';
require '../../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/PHPMailer/src/SMTP.php';
include "db_conn.php"; 

if (isset($_POST["signUp"])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}
	$name = validate($_POST['fname']);
	$uname = validate($_POST['Username']);
	$email = validate($_POST['email_address']);
	$pass = validate($_POST['pwd']);
	$re_pass = validate($_POST['confirm_pwd']);
	
	if(strlen($name)<2){
		header("Location: ../../views/new.php?error=shortname");
		exit();
	}
	elseif(!preg_match("/^[a-zA-Z\s]+$/",$name)){
		header("Location: ../../views/new.php?error=invalidname");
		exit();
	}
	elseif(strlen($uname)<2){
		header("Location: ../../views/new.php?error=shortuname");
		exit();
	}
	
	elseif(strlen($pass)<8){
		header("Location: ../../views/new.php?error=shortpwd");
		exit();
	}
	else if($pass !== $re_pass){
        header("Location: ../../views/new.php?error=pwdNotMatch");
	    exit();
	}elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
		header("Location: ../../views/new.php?error=InvalidMail");
		exit();
	}

	else{

		// hashing the password
        $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

		$sql = "SELECT * FROM user WHERE email=? ";
		$stmt = $conn->prepare($sql);
        $stmt->bind_param('ss',$email);
       // $stmt->execute();
		$result = $stmt->execute();

		if (mysqli_num_rows($result) > 0) {
			header("Location: ../../views/new.php?error=emailExists");
	        exit();
		}
		$sql1 = "SELECT * FROM user WHERE username='$uname' ";
			$result1 = mysqli_query($conn, $sql1);
		if(mysqli_num_rows($result1)>0){
			header("Location: ../../views/new.php?error=usernameExists");
				exit();
		}
		else {
           $sql2 = "INSERT INTO user(name,username,email, password) VALUES('$name','$uname','$email', '$hashedPass')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
			header("Location: ../../views/LoginForm.php?signup=success");
			exit();
			   /*$mail= new PHPMailer(true);
			   try {
				     //Server settings
                                    // Enable verbose debug output
									$mail->isSMTP();                                            // Send using SMTP
									$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
									$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
									$mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
									$mail->Password   = 'y@m1n@@UL';                               // SMTP password
									$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
									$mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
					
									//Recipients
									$mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
									$mail->addAddress("$email");     // Add a recipient               
									$mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
					
					
					
									// Content
									
									$mail->isHTML(true);                                  // Set email format to HTML
									$mail->Subject = 'Account Confirmation';
									$mail->Body    = "<h1>You have just created your email using $email  for Baipushi Security Services</h1>";
									$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
					
									$mail->send();
								if ($mail->send()) {
									header("Location: ../../views/LoginForm.php?signup=success");
	         						exit();
								}
								else {
									header("Location: ../../views/index.html?error=mailError");
									exit();
								}
			   } catch (Exception $e) {
				   header("Location: ../../views/index.html?error=mailError");
				   exit();
			   }*/
			
           }else {
	           	echo "sql error 75";
		        exit();
           }
		}
	}
	}

	
else{
	header("Location: ../../new.php");
	exit();
}
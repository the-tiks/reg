<?php

//session_start();

require 'db_conn.php';
/*use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/PHPMailer/src/Exception.php';
require '../../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/PHPMailer/src/SMTP.php';*/

$user["id"]=$_SESSION["id"];
$user["email"]=$_SESSION["email"];
$val=$user["id"];
$email=$user["email"];

    function getProfile($conn){
        $user["id"]=$_SESSION["id"];
        $val=$user["id"];
        $sql = "SELECT * FROM user WHERE id = '$val'";
        $result = mysqli_query($conn, $sql);
        
        if ($result) {
            echo "<form class='UserDetails' method='POST' action ='".editProfile($conn)."'>";
            while ($row = $result->fetch_assoc()) {
                $hashPass = password_needs_rehash($row["password"], PASSWORD_DEFAULT);
                echo "
                    <label>Name:</label><br>
                   <span><input type='text' name='Name' value='".$row["name"]."' required></span><span><button name='changeName' id='btn'>Update</button></span>
                   <label>Username:</label><br>
                   <span><input type='text' name='Username' value='".$row["username"]."' required></span><span><button name='changeUsername' id='btn'>Update</button></span>
                   <label>Email:</label><br>
                   <span><input type='email' name='Email' value='".$row["email"]."' required></span><span><button name='changeEmail' id='btn'>Update</button></span>
                   <label>Password:</label><br>
                   <span><input type='password' name='Password' value='".$row["password"]."' required></span><span><button name='changePassword' id='btn'>Update</button></span><br>
                   <p class='password'>Password cannot be shown due to security reasons</p><br>
                ";
            }
            echo "
                <button name='updateAll' id='updateBtn'>Update All</button>
            </form>";
        }
    }
    function editProfile($conn){
        $user["id"]=$_SESSION["id"];
        $val=$user["id"];

        if (isset($_POST["changeName"])) {
            $name = $_POST["Name"];
            $sql = "UPDATE user SET name='$name' WHERE id='$val'";
            $result = mysqli_query($conn, $sql);
            if($result){
                header("Location: ../../views/EditProfile.php?change=success");
                exit();
            }
            else{
                header("Location: ../../views/EditProfile.php?error=sql");
                exit();
            }
        }

        elseif (isset($_POST["changeUsername"])) {
            $username = $_POST["Username"];
            $sql1 = "UPDATE user SET username = '$username' WHERE id='$val'";
            $result1 = mysqli_query($conn, $sql1);
            if($result1){
                header("Location: ../../views/EditProfile.php?change=success");
                exit();
            }else{
                header("Location: ../../views/EditProfile.php?error=sql");
                exit();
            }
        }

        elseif (isset($_POST["changeEmail"])) {
            $email = $_POST["Email"];
            $sql2 = "UPDATE user SET email='$email' WHERE id='$val'";
            $result2 = mysqli_query($conn, $sql2);
            if($result2){
                header("Location: ../../views/EditProfile.php?change=success");
                exit();
            }
            else {
                header("Location: ../../views/EditProfile.php?error=sql");
                exit();
            }
        }

        elseif (isset($_POST["changePassword"])) {
            $password = $_POST["Password"];
            $hasPass = password_hash($password, PASSWORD_DEFAULT);
            $sql3 = "UPDATE user SET password='$hasPass' WHERE id='$val'";
            $result3 = mysqli_query($conn, $sql3);
            if ($result3) {
                header("Location: ../../views/EditProfile.php?change=success");
                exit();
            }
            else {
                header("Location: ../../views/EditProfile.php?error=sql");
                exit();
            }
        }

        elseif (isset($_POST["updateAll"])) {
            $Name = $_POST["Name"];
            $uname = $_POST["Username"];
            $mailId = $_POST["Email"];
            $pass = $_POST["Password"];

            $hashPass = password_hash($pass, PASSWORD_DEFAULT);
            $sql4 = "UPDATE user SET name='$Name',username='$uname',email='$mailId',password='$hashPass' WHERE id='$val'";
            $result4 = mysqli_query($conn, $sql4);
            if($result4){
                header("Location: ../../views/EditProfile.php?change=success");
                exit();
            }
            else {
                header("Location: ../../views/EditProfile.php?error=sql");
                exit();
            }
        }
    }
          /*  $mail = new PHPMailer(true);

            try {
                //Server settings
                                    // Enable verbose debug output
                $mail->isSMTP();                                            // Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
                $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
                $mail->Password   = 'y@m1n@@UL';                               // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

                //Recipients
                $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
                $mail->addAddress("$newEmail");     // Add a recipient               
                $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');



                // Content
                
                $mail->isHTML(true);                                  // Set email format to HTML
                $mail->Subject = 'Email  Update';
                $mail->Body    = "<h1>You have just changed your email from '$email' to '$newEmail' for your Baipushi Security Services account</h1>";
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();
                if($mail->send()){
                    header("Location: EditProfile.php?change=success");
                    exit();
                }
                else{
                    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
                    exit(); 
                }
            }
                
            catch (Exception $e) {
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
            exit();*/

            
﻿<?php 
session_start(); 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/PHPMailer/src/Exception.php';
require '../../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/PHPMailer/src/SMTP.php';
include "db_conn.php"; 

if (isset($_POST["submit"])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}
	$name = mysqli_real_escape_string($conn, $_POST['fname']);
	$uname = validate($_POST['username']);
	$email = validate($_POST['email']);
	$password = validate($_POST['password']);
	$re_password = validate($_POST['confirm_pwd']);

	$errorEmpty = false;
    $errorEmail = false;
    $errorEmailExists = false;
    $errorInvalidName = false;
    $errorShortPwd = false;
    $errorShortName = false;
	$errorPwdMismatch = false;
	
	if(empty($name) || empty($username) || empty($email) || empty($password) || empty($re_password)){
		echo "<span class='err-msg'>Fill in all fields</span>";
		$errorEmpty = true;
	}

	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "<span class='err-msg'>Invalid email address</span>";
		$errorEmail = true;
	}
	elseif (strlen($name)<2) {
		echo "<span class='err-msg'>Name is too short</span>";
		$errorShortName = true;
	}
	elseif (!preg_match("/^[a-zA-Z\s]+$/",$name)) {
		echo "<span class='err-msg'>Enter a valid name</span>";
		$errorInvalidName = true;
	}
	elseif (strlen($password)<8) {
		echo "<span class='err-msg'>Password must be at least 8 characters</span>";
		$errorShortPwd = true;
	}
	elseif ($password != $re_password) {
		echo "<span class='err-msg'>Passwords do not match!</span>";
	}
	else{

		// hashing the password
        $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

		$sql = "SELECT * FROM user WHERE email=? ";
		$stmt = $conn->prepare($sql);
        $stmt->bind_param('ss',$email);
       // $stmt->execute();
		$result = $stmt->execute();

		if (mysqli_num_rows($result) > 0) {
			echo "<span class='err-msg'>This email is already registered</span>";
               $errorEmailExists = true; 
		}
		else {
           $sql2 = "INSERT INTO user(name,username,email, password) VALUES('$name','$username','$email', '$hashedPass')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
			header("Location: ../../views/LoginForm.php?signup=success");
			exit();
			   /*$mail= new PHPMailer(true);
			   try {
				     //Server settings
                                    // Enable verbose debug output
									$mail->isSMTP();                                            // Send using SMTP
									$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
									$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
									$mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
									$mail->Password   = 'y@m1n@@UL';                               // SMTP password
									$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
									$mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
					
									//Recipients
									$mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
									$mail->addAddress("$email");     // Add a recipient               
									$mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
					
					
					
									// Content
									
									$mail->isHTML(true);                                  // Set email format to HTML
									$mail->Subject = 'Account Confirmation';
									$mail->Body    = "<h1>You have just created your email using $email  for Baipushi Security Services</h1>";
									$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
					
									$mail->send();
								if ($mail->send()) {
									header("Location: ../../views//LoginForm.php?signup=success");
	         						exit();
								}
								else {
									header("Location: ../../views/RegisterForm - Copy.php?error=mailError");
									exit();
								}
			   } catch (Exception $e) {
				   header("Location: ../../views/RegisterForm - Copy.php?error=mailError");
				   exit();
			   }*/
			
           }else {
	           	echo "sql error 75";
		        exit();
           }
		}
	}
	}

	
else{
	echo "Error 404!";
	exit();
}
?>

<script>
    $("#nameId, #usernameId, #mailId, #passwordId").removeClass("input-error");
    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorEmail = "<?php echo $errorEmail; ?>";
    var errorShortName = "<?php echo $errorShortName; ?>";
    var errorShortPwd = "<?php echo $errorShortPwd; ?>";
    var errorInvalidName = "<?php echo $errorInvalidName; ?>";
    var errorEmailExists = "<?php echo $errorEmailExists; ?>";


    if (errorEmpty == true ) {
        $("#nameId, #usernameId, #mailId, #passwordId").addClass("input-error");
    }

    if(errorShortName == true){
        $("#nameId").addClass("input-error");
    }

    if (errorInvalidName == true) {
        $("#nameId").addClass("input-error");
    }

    if (errorEmail == true) {
        $("#mailId").addClass("input-error");
    }
    
    if(errorShortPwd = true){
        $("#passwordId").addClass("input-error");
    }

    if(errorEmailExists =  true){
        $("#mailId").addClass("input-error");
    }

    if(errorEmpty == false && errorEmail == false && errorShortName == false 
    && errorInvalidName == false && errorShortPwd == false && errorEmailExists == false){
        $("#nameId, #usernameId, #mailId, #passwordId").val("");
    }
</script>

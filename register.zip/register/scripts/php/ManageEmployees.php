<?php
require 'db_conn.php';
function deleteRecord($conn){
    if(isset($_POST["deleteRecord-submit"])){
        $mailId = $_POST["mailId"];
        if(!filter_var($mailId, FILTER_VALIDATE_EMAIL)){
            header("Location: ../../views/AdminHome.php?error=InvalidEmail");
            exit();
        }
        else{
            $sql = "SELECT * FROM employees WHERE emp_email='$mailId'";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result)>0){
                $qry = "DELETE FROM employees WHERE emp_email='$mailId'";
                $res = mysqli_query($conn, $qry);
                if($res){
                    $qry1 ="DELETE FROM emp_login WHERE email='$mailId'";
                    $res1 = mysqli_query($conn, $qry1);
                    if($res1){
                        header("Location: ../../views/AdminHome.php?clear=success");
                        exit();
                    }
                    else {
                        header("Location; ../../views/AdminHome.php?error=sqlerr");
                        exit();
                    }
                }
                else {
                    echo"Unknown error has occurred";
                }
                
            }else{
                header("Location: ../../views/AdminHome.php?error=MailDntExist");
                exit();
            }
        }
    }
}


function searchEmployee($conn){
    if (isset($_POST["UpdateRecord-submit"])) {
        $EmailId = $_POST["EmailId"];
        $query = "SELECT * FROM employees WHERE emp_email='$EmailId'";
        $rs = mysqli_query($conn, $query);
        if (mysqli_num_rows($rs)>0) {
            header("Location: UpdateEmpDet.php?result=success");
            exit();
        }
        else{
            header("Location: ../../views/AdminHome.php?error=empnotfound");
            exit();
        }
    }
}

function getEmployeeDetails($conn){
    if(isset($_POST["UpdateRecord-submit"])){
        $EmailId = $_POST["EmailId"];
        $Query = "SELECT * FROM employees WHERE emp_email='$EmailId'";
        $Rs = mysqli_query($conn,$Query);
        $row=$Rs->fetch_assoc();
            echo"
            <div form class='res' method='post' action='updateEmp'>
            <input type='text' name='newName' value='".$row["emp_name"]."'>
            <input type='text' name='newLastame' value='".$row["emp_lastname"]."'>
            <input type='email' name='newMail' value='".$row["emp_email"]."'>
            <input type='text' name='newPostion' value='".$row["emp_position"]."'>
            <input type='text' name='newSalary' value='".$row["emp_salary"]."'>
            <input type='text' name='newNumber' value='".$row["emp_num"]."'>
            </div>
            ";
    }
}
<?php

 require 'db_conn.php';

 if (isset($_POST["create_Invoice"])) {
     $servRen = $_POST["serv"];
     $duration = $_POST["dur"];
     $date_rendered = $_POST["date"];
     $cost = $_POST["price"];
     $customer = $_POST["Customer-email"];
     $issued_by = $_POST["issued_by"];
     $emp_id = $_POST["emp_id"];
     $Invoice_date = $_POST["Invoice_date"];

     $sql = "INSERT INTO invoice (`service`, `duration`, `date`, `cost`, `customer_email`, `issued_by`, `emp_id`,`InvoiceDate`) VALUES 
     ('$servRen', '$duration', '$date_rendered', '$cost', '$customer', '$issued_by', '$emp_id', '$Invoice_date')";
     $result = mysqli_query($conn, $sql);
     if($result){
         header("Location: ../../views/EmpHome.php?invoice=success");
         exit();
     }
     else {
         echo"Sql error";
         exit();
     }
 }

 function getInvoices($conn){
     $sql = "SELECT * FROM invoice ";
     $result = mysqli_query($conn, $sql);
     echo"<table>";
     echo"<th>Service Rendered</th>";
     echo"<th>Duration</th>";
     echo"<th>Date</th>";
     echo"<th>Cost</th>";
     echo"<th>Customer Email</th>";
     echo"<th>Invoice Date</th>";
     while ($row=$result->fetch_assoc()) {
         echo"<tr>
         <td>".$row["service"]."</td>
         <td>".$row["duration"]."</td>
         <td>".$row["date"]."</td>
         <td class='price'>$".$row["cost"]."</td>
         <td>".$row["customer_email"]."</td>
         <td>".$row["InvoiceDate"]."</td>
         </tr>";
     }
     echo"</table>";
    
 }

 function getUserInvoices($conn){
     $currentMail['email'] = $_SESSION['email'];
    $activeMail =$currentMail['email'];
     $sql = "SELECT * FROM invoice WHERE customer_email='$activeMail'";
     $result = mysqli_query($conn, $sql);
     echo"<table class='full_view'>";
     echo"<th class='service'>Service</th>";
     echo"<th>Duration</th>";
     echo"<th class='date'>Date</th>";
     echo"<th class='cost'>Cost</th>";
     echo"<th class='customer'>Invoice Date</th>";
     
     while ($row=$result->fetch_assoc()) {
         echo"<tr>
         <td class='service'>".$row["service"]."</td>
         <td>".$row["duration"]."</td>
         <td>".$row["date"]."</td>
         <td class='price'>$".$row["cost"]."</td>
         <td>".$row["InvoiceDate"]."</td>
         </tr>";
     }
     echo"</table>";
     $invoice = $result->fetch_assoc();
 }

 function getUserInvoicesSmallScreen($conn){
    $currentMail['email'] = $_SESSION['email'];
    $activeMail =$currentMail['email'];
     $sql = "SELECT * FROM invoice WHERE customer_email='$activeMail'";
     $result = mysqli_query($conn, $sql);
     if(mysqli_num_rows($result)>0){
        while($row = $result->fetch_assoc()){
            echo "
            <table class='small_view'>
            <th class='left'>Index</th>
            <th class='right'>Description</th>
            <tr>
                <td class='left'>Service:</td>
                <td class='right'>".$row["service"]."</td>
            </tr>
            <tr>
                <td class='left'>Duration:</td>
                <td class='right'>".$row["duration"]."</td>
            </tr>
            <tr>
                <td class='left'>Date:</td>
                <td class='right'>".$row["date"]."</td>
            </tr>
            <tr>
                <td class='left'>Cost:</td>
                <td class='sm_price'>$".$row["cost"]."</td>
            </tr>
            <tr>
                <td class='left'>Invoice Date:</td>
                <td class='right'>".$row["InvoiceDate"]."</td
            </tr>
            </table>
         ";
         }
     }else{
         echo"<style text='css/stylesheet'>
            .noInvMsg{
                font-size: 20px;
                background: #071b30fa;
                align-items: center;
                position: relative;
                margin-left: 100px;
                color: #fff;
                height: 50px;
                padding: 3%;
                border-radius: 5px; 
                animation: zoomInOut 7s linear infinite;
            }
            @keyframes zoomInOut{
                0%,100%{
                    transform: scale(1);
                }
                50%{
                    transform: scale(1.1);
                }
            }
         </style>
        <p class='noInvMsg'> No invoices yet</p>";
       
     }
    
    
 }

 function getAllInvoices($conn){
     $sql = "SELECT * FROM invoice";
     $result = mysqli_query($conn, $sql);

     if (!$result) {
         echo "Sql error 300";
     }
     elseif(mysqli_num_rows($result)>0) {
         echo "<style text='css/stylesheet'>
                table{
                    width: 100%;
                    border: 0;
                    box-shadow: 0 2px 8px #000;
                    color: #fff;
                    background: #071b30fa;
                    font-family: sans-serif;
                    text-align: left;
                    line-height: 30px;
                    margin-top: 10px;
                    margin-bottom: 10px;
                }
                th{
                    text-align: left;
                    font-family: sans-serif;
                    color: #fff;
                    background: #1988f0;
                    line-height: 40px;
                    padding: 2px;
                    box-shadow: 0 2px 8px #1988f0;
                }
                .price{
                    color: #17f33c;
                }
                .email{
                    width: 100px;
                }
                
                </style>
         <table>
         <th>Service</th>
         <th>Duration</th>
         <th>Date</th>
         <th>Cost</th>
         <th class='email'>Issued To</th>
         <th class='email'>Issued By</th>
         ";
         while ($row = $result->fetch_assoc()) {
             echo "
             <tr>
                <td>".$row["service"]."</td>
                <td>".$row["duration"]."</td>
                <td>".$row["date"]."</td>
                <td class='price'>$".$row["cost"]."</td>
                <td class='email'>".$row["customer_email"]."</td>
                <td class='email'>".$row["issued_by"]."</td>
                
             </tr>
             ";
         }
         echo "</table>";
     }
     else {
                echo "<style text='css/stylesheet'>
                table{
                    width: 100%;
                    border: 0;
                    box-shadow: 0 2px 8px #000;
                    color: #fff;
                    background: #071b30fa;
                    font-family: sans-serif;
                    text-align: left;
                    line-height: 30px;
                    margin-top: 10px;
                    margin-bottom: 10px;
                }
                th{
                    text-align: left;
                    font-family: sans-serif;
                    color: #fff;
                    background: #1988f0;
                    line-height: 40px;
                    padding: 2px;
                    box-shadow: 0 2px 8px #1988f0;
                }
                .price{
                    color: #17f33c;
                }
                .email{
                    width: 100px;
                }
                
                </style>
        <table>
        <th>Service</th>
        <th>Duration</th>
        <th>Date</th>
        <th>Cost</th>
        <th class='email'>Issued To</th>
        <th class='email'>Issued By</th>
        </table><br>";
        echo "No invoices yet";
     }
 }
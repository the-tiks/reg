<?php
    include("db_conn.php");
    if(!isset($_GET["code"])){
        exit("can't find page");
    }
    else{
        $code= $_GET["code"];

    $sql2 = "SELECT email FROM resetpassword WHERE code = '$code'";
    $getEmailQuery = mysqli_query($conn, $sql2);
    if(mysqli_num_rows($getEmailQuery)>1){
        exit("Can't find page");
    }
    if(isset($_POST["password"])){
        $pw= $_POST["password"];
        $hashedPW = password_hash($pw,PASSWORD_DEFAULT);

        $row=mysqli_fetch_array($getEmailQuery);
        $email=$row["email"];
        $sql3= "UPDATE user SET password ='$hashedPW' WHERE email='$email'";
        $query=mysqli_query($conn,$sql3);
        if($query){
            $sql4="DELETE  FROM resetpassword code='$code'";
            $query= mysqli_query($conn,$sql4);
            header("Location: ../../views/LoginForm.php?ress=success");
            exit();
        }else{
            exit("Something's gone wrong");
        }
    }

    }

    
?>
<link rel="stylesheet" href="../../styles/StyleSheet1.css" />
<div class="UpdatePass">
<form method="POST">
    <?php
    if(isset($_GET["ress"])){
       echo" <div class='success_message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Password reset successfully, login here</p>
                    </div>
                </div>
                <script src='../scripts/js/success_messages.js'></script>";
    }
    ?>
    <input type="password" name="password" placeholder="Enter new password">
    <br>
    <button type="submit" name="submit" id="bt">Submit</button>
</form>
</div>
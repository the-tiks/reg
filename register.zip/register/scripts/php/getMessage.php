<?php
require 'db_conn.php';
function messageArea($conn){
    echo"<style text='css/stylesheet'>
            label{
                float: left;
                
            }
            textarea{
                width: 100%;
            }
            .response_msg .response .message_body{
                float:left;
            }
            p{
                float: right;
                width: 100%;
                line-height: 20px;
                margin-top:0px;
          
            }
        </style>
        <form class='chatArea' method='POST' action='".sendMessages($conn)."'>
        <label>Hi ".$_SESSION["name"].", How can I help you?</label>
        <input type='hidden' name='mailId' value=".$_SESSION["email"].">
        ";
        echo "<div class='response'>
            <p class='response_msg'>".getResponse($conn)."<p>
           </div> ";
           echo "<div class='msg_body'>";
           echo"".getUserMessages($conn)."
                <style text='css/stylesheet'>
                textarea{
                    width: 100%;
                }
                </style>
                <textarea name='message' placeholder='Type message'></textarea><br>
                <button name='send_msg'>send</button></div>";
   ;echo"
 </form>"; 
}
function sendMessages($conn){
    if(isset($_POST["send_msg"])){

        $msg = $_POST["message"];
        $senderMail = $_POST["mailId"];
        $sql = "INSERT INTO messages (message, senderEmail) VALUES ('$msg', '$senderMail')";
        $result = mysqli_query($conn, $sql);

        if($result){
          
        }
        else {
            echo"sql error1";
        }
    }
}
    function getMessages($conn){
        if (isset($_SESSION["empId"])) {
            $sql = "SELECT * FROM messages";
            $result = mysqli_query($conn, $sql);
            if($result){
             
                echo"<form class='UserMessages'method='post' action='".response($conn)."'>
                    <h1>Messages</h1>";
                    if(mysqli_num_rows($result)>0){
                        while ($row=$result->fetch_assoc()) {
                        
                            echo "<label>From:".$row["senderEmail"]."</label>
                            
                            <p class='message'>".$row["message"]."</p>
                            <input type='hidden' name='recepientEmail' value=".$row["senderEmail"].">";
                         
                           echo" <textarea name='response' placeholder='Type response'></textarea>
                            " ;
                         
                         echo"
                         <input type='hidden' name='responderEmail' value=".$_SESSION['emp_mail'].">";
                         

                         echo"<button name='reply'>Reply</button><br>";
                     }
                    }else{
                        echo "<p>No messages yet</p>";
                    }
                    echo "".response($conn)."";
                    echo"</form>";
            }
            else {
                echo "sql error";
            }
        }
      
    }

    function response($conn){
        if(isset($_POST["reply"])){

            $message = $_POST["response"];
            $receiver = $_POST["recepientEmail"];
            $responder = $_POST["responderEmail"];
            if(empty($receiver)){
                echo "No messages yet";
            }else{
                $sql = "INSERT INTO `response`( `message`, `responder`, `recepient`)
                VALUES ('$message', '$responder', '$receiver')";
               $result = mysqli_query($conn, $sql);
   
               if($result){
                   echo "
                   <style>
                   .message_body{
                       float: right;
                       font-family: sans-serif;
                       background: #071b30fa;
                       line-height: 30px;
                       color: #071b30fa;
                   }
                   </style>
                   <form class='response'>
                       <p class='message_body'>$message<p>
                       <p class='recepient'>To: ".$receiver."</p>
                       </form>
                   ";
               }
               else {
                   echo "something's gone wrong";
               }
            }
           
        }
    }

function getResponse($conn){
    $currentMail["email"] = $_SESSION["email"];
    $activeMail = $currentMail["email"];
    $sql = "SELECT * FROM response WHERE recepient='$activeMail'";
    $result = mysqli_query($conn, $sql);
    if($result){
       while ($row = $result->fetch_assoc()) {
        echo "
        <p class='response_body'>".$row["message"]."</p>
    ";
    } 

    }
    else {
        echo "Something's gone wrong";
        exit();
    }
}

function getUserMessages($conn){
    
    $currentMail["email"] = $_SESSION["email"];
    $activeMail = $currentMail["email"];
    $sql = "SELECT * FROM messages WHERE senderEmail ='$activeMail'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "<p class='msg_body'>".$row["message"]."</p>";
        }
    }   

}
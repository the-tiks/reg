<?php

    if (isset($_POST["directUser"])) {
        header("Location:../../views/LoginForm.php");
        exit();
    }
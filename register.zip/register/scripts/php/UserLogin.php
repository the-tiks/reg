<?php 
session_start();
require 'db_conn.php';

if(isset($_POST['login-submit'])){
    
    $email=$_POST['email'];
    $password=$_POST['pwd'];
   /* if(empty($email) || empty($password)){
        header("Location: ../../views/index.html?error=emptyfields".$email);
        exit();

    }
    else{*/
        

        $sql="SELECT * FROM emp_login WHERE email=? limit 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s',$email);
        $stmt->execute();
        $result=$stmt->get_result();
        $user= $result->fetch_assoc();
        if(password_verify($password, $user["password"])){
            
            session_start();
            $_SESSION['empId'] = $user['id'];
            $_SESSION['emp_mail']= $user['email'];
            $_SESSION['last_login_timestamp'] = time();

            header("Location: ../../views/EmpHome.php?login=success");
            exit();
        }else{
        

            $sql="SELECT * FROM user WHERE email=? OR username=? limit 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ss',$email,$email);
            $stmt->execute();
            $result=$stmt->get_result();
            $user= $result->fetch_assoc();
            
        
            
            if($email=='admin@gmail.com' && $password=='y@m1n@@UL'){
                session_start();
            $_SESSION['adminId'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['last_login_timestamp'] = time();

            //flash message
            $_SESSION['message'] = "You are now logged in";
            $_SESSION['alert-class'] ="alert-success";
       
                header("Location: ../../views/AdminHome.php?login=Success");
                exit();
            }elseif(password_verify($password, $user['password'])){
                session_start();
            $_SESSION['id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['last_login_timestamp'] = time();

            //flash message
            $_SESSION['message'] = "You are now logged in";
            $_SESSION['alert-class'] ="alert-success";
            header("Location: ../../views/Homepage.php?login=success");
            exit();
            }
    
            else {
                header("Location: ../../index.html?error=WrongDetails");
                exit();
             }
    
         }
   //}

}else {
    header("Location: ../../views/index.html?error=unknown");
    exit();
}  
           

?>
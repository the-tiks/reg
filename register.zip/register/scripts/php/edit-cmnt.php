<?php
require 'comments.php';

?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Edit Comment</title>
        <link rel="stylesheet" href="../styles/styling.css">  
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="refresh" content="300" > 
    </head>
<body>
    <?php
        $id = $_POST['id'];
       $userId = $_POST['uid'];
       $Date = $_POST['date'];
       $Msg = $_POST['message']; 

       echo" <form class='cmnt'method='post' action='".editComments($conn)."'>
       <input type='hidden' name='id' value='".$id."'>
       <input type='hidden' name='uid' value='".$userId."'>
       <input type='hidden' name='date' value='".$Date."'>
       <textarea name='message' value ='".$Msg."'required></textarea><br>
       <button type='submit' name='Comment-submit'>Comment</button>
       </form>";
    ?>

</body>
</html>
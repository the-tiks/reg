<?php
    require 'ManageEmployees.php';

  echo"  <div form class='res' method='post' action='updateEmp'>
    <input type='text' name='newName' value='".$row["emp_name"]."'>
    <input type='text' name='newLastame' value='".$row["emp_lastname"]."'>
    <input type='email' name='newMail' value='".$row["emp_email"]."'>
    <input type='text' name='newPostion' value='".$row["emp_position"]."'>
    <input type='text' name='newSalary' value='".$row["emp_salary"]."'>
    <input type='text' name='newNumber' value='".$row["emp_num"]."'>
    </div>";

    <?php
session_start();
require 'db_conn.php';

    if(isset($_POST["deleteRecord-submit"])){

        $dltEmail=$_POST["mailId"];

        if(!filter_var($dltEmail, FILTER_VALIDATE_EMAIL)){
            header("location: ../Views/AdminHome.php?error=InvalidEmail");
            exit();
        }
        else{

            $sql="SELECT * FROM employees WHERE emp_email='$dltEmail'";
            $res=mysqli_query($conn,$sql);
            if(mysqli_num_rows($res)>0){
                
                $qry="DELETE FROM employees WHERE emp_email='$dltEmail'";
                $result=mysqli_query($conn,$qry);
                if($result){

                    $stmt="DELETE FROM emp_login WHERE email='$dltEmail'";
                    $rslt=mysqli_query($conn,$stmt);

                    if ($rslt) {

                        header("Location: ../Views/AdminHome.php?clear=success");
                         exit();

                    }else {

                        header("Location: ../Views/AdminHome.php?error=sql");
                        exit();
                    }
                    
                }
                else{
                    header("Location: ../Views/AdminHome.php?error=sql");
                    exit();
                }
            }
            else{
                header("Location: ../Views/AdminHome.php?error=MailDntExist");
                exit();
            }
        }
    }elseif(isset($_POST["UpdateRecord-submit"])){
        $UpEmail=$_POST["EmailId"];

        if(!filter_var($UpEmail,FILTER_VALIDATE_EMAIL)){
            header("Location: ../Views/AdminHome.php?error=InvalidEmail");
            exit();
        }
        else {
            function getEmployeeDetails($conn){
                $Query = "SELECT * FROM employees WHERE emp_email='$UpEmail'";
                $rs = mysqli_query($conn,$Query);
                $row=$rs->fetch_assoc();
                if(mysqli_num_rows($rs)>0){
                    echo"
                    <div form class='res' method='post' action='updateEmp'>
                    <input type='text' name='newName' value='".$row["emp_name"]."'>
                    <input type='text' name='newLastame' value='".$row["emp_lastname"]."'>
                    <input type='email' name='newMail' value='".$row["emp_email"]."'>
                    <input type='text' name='newPostion' value='".$row["emp_position"]."'>
                    <input type='text' name='newSalary' value='".$row["emp_salary"]."'>
                    <input type='text' name='newNumber' value='".$row["emp_num"]."'>
                    </div>
                    ";
                }
                else {
                    header("Location: ../Views/AdminHome.php?error=empnotfound");
                    exit();
                }
            }
           
        }
    }

?>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../styles/manage.css">
    <link rel="stylesheet" href="../styles/AdmnStylng.css">
    <title>Manage Employees</title>
</head>
<body>
    <?php
        if(isset($_SESSION["adminId"])){
            echo'';
            
        }
        else{
            header("Location: ../Views/home.php");
            exit();
        }
    ?>
    <header>
        <nav>
            <a href="#">Invoices</a>
            <a href="#">Invoices</a>
            <a href="#">Invoices</a>
        </nav>
    </header>
    <div class="Cont">
        <form class="col-1">
        <table>
        <form method="post" action="../scripts/addEmp.php">
            <?php
            if(isset($_GET["error"])){


                if($_GET["error"]=="emptyfields"){
                    echo'<p class="error-msg">Fill in all fields</p>';
                }elseif($_GET["error"]=="invalidmail"){
                    echo'<p class="error-msg">This email is invalid</p>';
                }elseif($_GET["error"]=="emailtaken"){
                    echo'<p class="error-msg">This email already exists</p>';
                }elseif($_GET["error"]=="numbertaken"){
                    echo'<p class="error-msg"This number already exists</p>';
                }elseif($_GET["error"]=="failed"){
                    echo "$mail->ErrorInfor";
                }elseif ($_GET["error"]=="shortName") {
                    echo'<p class="error-msg">Name is too short</p>';
                }elseif ($_GET["error"]=="shortLastName") {
                    echo'<p class="error-msg">Lastname is too short</p>';
                }elseif ($_GET["error"]=="invalidName") {
                    echo'<p class="error-msg">Enter a valid name</p>';
                }elseif ($_GET["error"]=="invalidLastName") {
                    echo'<p class="error-msg">Enter a valid Lastname</p>';
                }elseif ($_GET["error"]=="invalidNumber") {
                    echo'<p class="error-msg">Enter a valid number </p>';
                }elseif ($_GET["error"]=="shortNumber") {
                    echo'<p class="error-msg">Number is too short</p>';
                }elseif ($_GET["error"]=="bigNumber") {
                    echo'<p class="error-msg">Number is too large</p>';
                }
            }elseif(isset($_GET["signup"])){
                if($_GET["signup"]=="Success"){
                    echo'<p class="success-msg">Employee recorded added successfully</p>';
                }
            }
            ?>
        <tr><td><h2>Employee Record</h2></td></tr>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name" required></td>
        </tr>
        <tr>
            <td>Lastame:</td>
            <td><input type="text" name="Lastname" required></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="email" name="email_ad" required></td>
        </tr>
        <tr>
            <td>Position:</td>
            <td><input type="text" name="Pos" required></td>
        </tr>
        <tr>
            <td>Salary:</td>
            <td><input type="text" name="Salary" required></td>
        </tr>
        <tr>
            <td>Phone:</td>
            <td><input type="text" name="ContactNum" required></td>
        </tr><br>
        <tr><td><button class="btn" type="submit" name="regUser" >Add Employee</button></td></tr>
        </form>
    </table>
        </form><br>

        <form class="col-2" method="post" action="ManageEmployees.php"> 
            <?php
                if(isset($_GET["error"])){
                    if($_GET["error"]=="InvalidEmail"){
                        echo'<p class="error-msg">This email is invalid';
                    }
                    elseif($_GET["error"]=="MailDntExist"){
                        echo'<p class="error-msg">No existing record registered with this email</p>';

                    }
                }
                elseif(isset($_GET["clear"])){
                    if($_GET["clear"]=="success"){
                        echo'<p class="success-msg">Record deleted successfully</p>';
                    }
                }
            ?>
            <h2>Delete Record</h2>
            <label>Email:</label><br>
            <input type="email" name="mailId" placeholder="Enter email address" required><br>
            <button type="submit" name="deleteRecord-submit" id="btn">Delete Record</button>
        </form>

        <form class="col-3" method="post" action="ManageEmployees.php">
                
            <h2>Update Employee Record</h2>
            <label>Email:</label>
            <input type="email" name="EmailId" placeholder="Enter email address" required>
            <button type="submit"  name="UpdateRecord-submit" id="btn">Search</button>
        </form>

        <form class="col-4">
        <table>
                <tr>
                    <td><h2>Taaa</h2</td>
                </tr>
          </table>
        </form>
        <a href="../Views/home.php"><img src="https://img.icons8.com/ios/50/000000/backspace.png" 
        width="50px"
         height="40px"></a>

    </div>
</body>
</html>
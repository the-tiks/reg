<?php

session_start();
require 'db_conn.php';

if(isset($_POST["delete-acc"])){

    if(isset($_SESSION['id'])){
        $user["id"]= $_SESSION['id'];
        $val=$user["id"];
        $stmt ="DELETE FROM user WHERE id='$val'";
        $res= mysqli_query($conn,$stmt);

        if($res){
            session_destroy();
            unset($_SESSION["id"]);
            unset($_SESSION["name"]);
            unset($_SESSION["email"]);

            if(session_destroy()){
                header("Location: ../../views/home.php?");
                exit();
            }
            else {
                header("Location: ../../views/home.php?errorfailed");
                exit();
            }
        }

        else {
            header("Location: ../../views/home.php?error=sqlError");
            exit();
        }
    }
    else {
        echo"Unable to connect";
    }

       
}
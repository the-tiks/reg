<?php

require 'db_conn.php';

function setComments($conn){
    if (isset($_POST["Comment-submit"])) {

        $userId = $_POST['uid'];
        $Date = $_POST['date'];
        $Msg = $_POST['message'];

        $sql = "INSERT INTO comments (uid, date, message) VALUES ('$userId','$Date', '$Msg')";
        $result = mysqli_query($conn,$sql);
    
    }
}

function getComments($conn){
   
    
    if (isset($_SESSION["id"])) {
        $sql2 = "SELECT * FROM comments";
        $result2 = mysqli_query($conn, $sql2);
        while ($rows = $result2->fetch_assoc()) {
            echo " <style text='css/stylesheet'>
            .comment-box{
                width: 100%;
                background: #fff;
                

              }
              .comment-box label{
                font-weight: bold;
                font-family: sans-serif;
                float: left;
                text-align: left;
                width: 100%;
                
                color: #0476aa;
              }
              
              .comment-box .date{
                float: right;
                width: 100%;
                text-align: right;
                font-size: 12px;
                font-weight: bold;
                margin-top: 0;
                color: green;
              }
              #editBtn{
                background: #071b30fa;
                color: #fff;
                width: 100px;
                height: 30px;
                border: 1px;
                border-radius: 5px;
                cursor: pointer;
                
                }
                #deleteBtn {
                background: red;
                color: #fff;
                width: 100px;
                height: 30px;
                border: 1px;
                border-radius: 5px;
                cursor: pointer;
                } 
                #editBtn:hover{
                    background: #fff;
                    color: #0476aa;
                    border: 2px solid #0476aa;
                    
                }
                #deleteBtn:hover{
                    background: #fff;
                    color: green;
                    border: 2px solid green;
                }
            </style>
            <div class='comment-box'>";
            echo"<label>".$rows["uid"]."</label><br>";
            if($rows["uid"] == $_SESSION["username"]){
                $found = $_SESSION["username"];
                $sql3 = "SELECT * FROM comments WHERE uid = '$found'";
                $result3 = mysqli_query($conn, $sql3);
                if (!$result3) {
                    echo "sql error6";
                }
                else {
                    while ($ROW=$result3->fetch_assoc()) {
                        echo " <style text='css/stylesheet'>
                           
                        </style><form method='POST' action='".editUserComment($conn)."'>
                        <p class='message'>".$ROW["message"]."</p>
                        <input type='hidden' name='id' value=".$ROW["id"].">
                        <input type='hidden' name='msg' value=".$ROW["message"].">
                        <button name='editBtn' id='editBtn'>Edit</button>
                        <button name='deleteBtn' id='deleteBtn'>Delete</button>
                        </form>
                    ";
                    }
                }
               
            }
            else {
                echo "<style text='css/stylesheet'>
                        .message{
                            width: 100%;
                            text-align: left;
                        }   
                </style>
               
                <p class='message'>".$rows["message"]."</p>
                <p class='date'>".$rows["date"]."</p>
                
                ";
            }
        }
    }
    else {
        $sql = "SELECT * FROM comments";
        $result = mysqli_query($conn, $sql);
        while ($row = $result->fetch_assoc()) {
            echo"
            <style text='css/stylesheet'>
                        label{
                            width: 100%;
                            color: #0476aa;
                            float: left;
                            font-weight: bold;
                            text-align: left;
                        }  
                        .msg_body{
                            float: left;
                            width: 100%;
                            text-align: left;
                            margin-top: 0;
                        }
                        .dte{
                            text-align: right;
                            margin-top: 0;
                            width:100%;
                            font-size: 12px;
                            font-weight: bold;
                            color: #000;
                            
                        }
                </style>";
                echo "<label>".$row["uid"]."</label><br>";
                echo "<p class='msg_body'>".nl2br($row["message"])."</p>";
                echo "<p class='dte'>".$row["date"]."</p>";
            echo"
            <form method='post' action='edit-cmnt.php'>
                <input type='hidden' name='id' value='".$row["id"]."'>
                <input type='hidden' name='uid' value='".$row["uid"]."'>
                <input type='hidden' name='date' value='".$row["date"]."'>
                <input type='hidden' name='message' value=".$row["message"].">
                
            </form>
            ";
        }
    }
    
    
}

function editComments($conn){
    if (isset($_POST["Comment-submit"])) {
        $id = $_POST["id"];
        $userId = $_POST["uid"];
        $Date = $_POST["date"];
        $Msg = $_POST["message"];

        $sql="UPDATE comments SET message='$Msg' WHERE id='id'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header("Location: ../../index.php?edit=success");
            exit();
        }
    }
}

function commentsOnLogin($conn){
    if(isset($_POST["comment-submit"])){
        $Uid = $_POST["UserName"];
        $dt = $_POST["date"];
        $ms = $_POST["message"];
        $sql = "INSERT INTO comments (uid, date, message) VALUES ('$Uid', '$dt', '$ms')";
        $result = mysqli_query($conn, $sql);
        if(!$result){
            echo "Sql error3";

        }
     
    }
}
function editUserComment($conn){
    if(isset($_POST["deleteBtn"])){
        $commentId = $_POST['id'];
        $sql = "DELETE FROM comments WHERE id='$commentId'";
        $result = mysqli_query($conn, $sql);
        if(!$result){
            echo "sql 99";
            exit();
        }
    }
    elseif (isset($_POST["editBtn"])) {
        
        $commentorId = $_POST["id"];
        $sql = "SELECT * FROM comments WHERE id='$commentorId'";
        $result = mysqli_query($conn, $sql);
        $rows=$result->fetch_assoc();
        
        echo"<form method='POST' action='".updateComment($conn)."'>
        <textarea name='updateMsg' value='".$rows["message"]."'></textarea><br>
        <input type='hidden' name='id' value=".$commentorId.">
        <button name='updateComment' >Comment</button>
        </form>";
    }
}
function updateComment($conn){
    if (isset($_POST["updateComment"])) {
        $nsg = $_POST["updateMsg"];
        $uid = $_POST["id"];

        $sql = "UPDATE comments SET message='$nsg' WHERE id='$uid'";
        $res = mysqli_query($conn, $sql);
        if(!$res){
            echo "sql error 404";
            exit();
        }
    }
}
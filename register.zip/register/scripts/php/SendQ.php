<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/PHPMailer/src/Exception.php';
require '../../PHPMailer/PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/PHPMailer/src/SMTP.php';

if(isset($_POST["mail_id"]) && isset($_POST["K9Quote"]) &&isset($_POST["GQuote"])
 && isset($_POST["AEQuote"]) &&isset($_POST["VIPQuote"])){

    $emailTo = $_POST["mail_id"];

    $mail = new PHPMailer(true);

try {
    //Server settings
                        // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
    $mail->Password   = 'y@m1n@@UL';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
    $mail->addAddress("$emailTo");     // Add a recipient               
    $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');



    // Content
    
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'All service quotations';
    $mail->Body    = "<h1>You have requested a quotation of all our services</h1>
                        Download attached file below ";
    $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
    $mail->addAttachment('../docs/VIPQUOTE.docx', 'VIPQUOTE.docx');
    $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
    $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    if($mail->send()){
        echo("Message sent successfully");
        exit();
    }
    else{
        echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
        exit(); 
    }
}
    
 catch (Exception $e) {
echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
exit();



 }
 elseif(isset($_POST["mail_id"]) && isset($_POST["K9Quote"]) &&isset($_POST["GQuote"])
 && isset($_POST["AEQuote"])){
    $emailTo = $_POST["mail_id"];

    $mail = new PHPMailer(true);

try {
    //Server settings
                        // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
    $mail->Password   = 'y@m1n@@UL';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
    $mail->addAddress("$emailTo");     // Add a recipient               
    $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');



    // Content
    
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'All service quotations';
    $mail->Body    = "<h1>You have requested a quotation of our services</h1>
                        Download attached file below ";
    $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
    $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
    $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    if($mail->send()){
        echo("Message sent successfully");
        exit();
    }
    else{
        echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
        exit(); 
    }
}
    
 catch (Exception $e) {
echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
exit();



 }

 //K9 Patrols quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["K9Quote"])){
   
   $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'K9 Patrol Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our K9 Patrols</h1>
                            Download attached file below ";
        $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();
 }

 //Armed escort quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["AEQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Armed Escort Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Armed Escort Services</h1>
                            Download attached file below ";
        $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

//Physical Guard quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["GQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Physical Guard Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Physical Guard Services</h1>
                            Download attached file below ";
        $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

//VIP personal protection quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["VIPQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'VIP Personal Protection services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our VIP Personal Protection services</h1>
                            Download attached file below ";
        $mail->addAttachment('../docs/VIPQUOTE.docx', 'VIPQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

 //K9 patrol and Physical Guard quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["K9Quote"]) &&isset($_POST["GQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Physical Guard and K9 Patrol services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Physical Guard and K9 Patrol services</h1>
                            Download attached file below ";
        $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
        $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

 //K9 patrol and VIP personal protection quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["K9Quote"]) &&isset($_POST["VIPQuote"])){
     
    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'VIP Protection and K9 Patrol Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our VIP Protection and K9 Patrol services</h1>
                            Download attached files below ";
        $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
        $mail->addAttachment('../docs/VIPQUOTE.docx', 'VIPQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

 //K9 patrol and Armed Escort quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["K9Quote"]) &&isset($_POST["AEQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Armed Escort and K9 Patrol Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Armed Escort and K9 Patrol services</h1>
                            Download attached files below ";
        $mail->addAttachment('../docs/K9Quote.docx', 'K9Quote.docx');
        $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

 }

 //VIP protection and Physical Guard quotation
 elseif(isset($_POST["mail_id"]) && isset($_POST["GQuote"]) &&isset($_POST["VIPQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Physical Guard and VIP Protection Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Physical Guard and VIP Protection services</h1>
                            Download attached files below ";
        $mail->addAttachment('../docs/VIPQUOTE.docx', 'VIPQUOTE.docx');
        $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

}

//Armed Escort and Physical Guard quotation
elseif(isset($_POST["mail_id"]) && isset($_POST["GQuote"]) &&isset($_POST["AEQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Physical Guard and Armed Escort Services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Physical Guard and Armed Escort services</h1>
                            Download attached files below ";
        $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
        $mail->addAttachment('../docs/PHYSICALGUARDQUOTE.docx', 'PHYSICALGUARDQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

}

//Armed Escort and VIP protection quotation
elseif(isset($_POST["mail_id"]) && isset($_POST["AEQuote"]) &&isset($_POST["VIPQuote"])){

    $emailTo=$_POST["mail_id"];
    $mail = new PHPMailer(true);

    try {
        //Server settings
                            // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'tonimack.ul@gmail.com';                     // SMTP username
        $mail->Password   = 'y@m1n@@UL';                               // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('tonimack.ul@gmail.com', 'Baipushi');
        $mail->addAddress("$emailTo");     // Add a recipient               
        $mail->addReplyTo('no-reply@mathikithelatc.com', 'No reply');
    
    
    
        // Content
        
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Armed Escort and VIP Protection services Quotation and details';
        $mail->Body    = "<h1>You have requested a quotation of our Armed Escort and VIP Protection services</h1>
                            Download attached files below ";
        $mail->addAttachment('../docs/ARMEDESCORTQUOTE.docx', 'ARMEDESCORTQUOTE.docx');
        $mail->addAttachment('../docs/VIPQUOTE.docx', 'VIPQUOTE.docx');
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        if($mail->send()){
            echo("Message sent successfully");
            exit();
        }
        else{
            echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");   
            exit(); 
        }
    }
        
     catch (Exception $e) {
    echo ("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");}   
    exit();

}
 else{
     header("Location: ../Views/EmpHome.php?error=check");
     exit();
 }
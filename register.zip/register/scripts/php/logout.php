<?php
session_start();
if(isset($_POST["logout"])){

    session_destroy();
    unset($_SESSION["empId"]);
    unset($_SESSION["adminId"]);
    unset($_SESSION["name"]);
    header('location: ../../index.php');
    exit();
    
}elseif (isset($_POST["user_logout"])) {
    include "db_conn.php";
    $currentMail['email'] = $_SESSION['email'];
    $activeMail =$currentMail['email'];
    $sql = "DELETE FROM `messages` WHERE senderEmail='$activeMail'";
    $result =mysqli_query($conn,$sql);
    if($result){

        $sql1 = "DELETE FROM `response` WHERE recepient='$activeMail'";
        $res = mysqli_query($conn, $sql1);
        if($res){
            session_destroy();
            unset($_SESSION['id']);
            unset($_SESSION["username"]);
            unset($_SESSION["email"]);
            header('location: ../../index.php');
            exit();
        }
        else {
            echo "sql error2";
        }
       
    }else{
        echo"sql error1";
    }

}
else{
    header("Location: ../../index.php");
    exit();
}
<?php

 session_start();
require './scripts/php/comments.php';
 date_default_timezone_set('Africa/Johannesburg');
?>
<!DOCTYPE hmtl>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Baipushi Security Services</title>
        <link rel="stylesheet" href="./styles/homecss.css"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="refresh" content="30" > 
    </head>
    
<body>
    <?php
        if(isset($_SESSION["id"])){
            header("Location: ./views/Homepage.php");
            exit();
        }elseif (isset($_SESSION["adminId"])) {
            header("Location: ./views/AdminHome.php");
            exit();
        }elseif (isset($_SESSION["empId"])) {
            header("Location: ./views/EmpHome.php");
            exit();
        }
        else{
            echo'';}
         ?>
         <?php
            if(isset($_GET["error"])){
                if($_GET["error"]=="expiredsess"){
                    echo"<div class='message-popup'>
                    <div class='box'>
                        <div class='close'>&times;</div>
                        <p>Your session has expired due to inactivity, login again</p>
                    </div>
                </div>
                <script src='./scripts/js/error_messages.js'></script>";
                }
            }
         ?>
         <div class="box-area">
     
         <div class="backdrop"></div>
            <header class="main-header">
                <button id="side-menu-toggle">Menu</button>
                <div class="logo">
                        <a href="#"><img src="./images/logo.png" height=55 width=300></a>
                    </div>
                <nav class="main-header__nav">
                    <ul class="main-header__item-list">
                        <li class="main-header__item">
                            <a  href="#">Shop</a>
                        </li>
                        <li class="main-header__item">
                            <a  href="#">Products</a>
                        </li>
                        <li class="main-header__item">
                            <a href="#">Cart</a>
                        </li>
                        <li class="main-header__item">
                            <a href="#">Orders</a>
                        </li>
                        <li class="main-header__item">
                            <a href="./views/Services.php">Services
                            </a>
                        </li>
                        <li class="main-header__item">
                          <form method="post" action="./scripts/php/script.php">
                            <button type="submit" name="directUser" id="loginBtn" target="_blank"> Login</button>
                            </form>
                        </li>
                    </ul>
                </nav>
            </header>
            <nav class="mobile-nav">
                <ul class="mobile-nav__item-list">
                        <li class="mobile-nav__item">
                            <a  href="#">Shop</a>
                        </li>
                        <li class="mobile-nav__item">
                            <a  href="#">Products</a>
                        </li>
                        <li class="mobile-nav__item">
                            <a  href="#">Cart</a>
                        </li>
                        <li class="mobile-nav__item">
                            <a  href="#">Orders</a>
                        </li>
                        <li class="mobile-nav__item">
                            <a  href="./views/Services.php">Services
                            </a>
                        </li>
                        <li class="mobile-nav__item">
                        <form method="post" action="./scripts/php/script.php">
                            <button type="submit" name="directUser" id="loginBtn" target="_blank"> Login</button>
                            </form>
                        </li>
                    </ul>
        </nav>
        <script src="./scripts/js/main.js"></script>
     
            <div class="content-area">
                <div class="description">
                        <h1>About Us</h1>
                    <p>Welcome to Baipushi Armed Security, a world class security company founded in 2014. Baipushi Armed Security employs approximately 
                        2000 employees and is ranked amongst the larger black privately owned security companies is South Africa.

                        Baipushi Armed Security is active in all major cities, and our service offerings cover the commercial, industrial,
                        tertiary, retail, freight, and banking sectors.

                        Baipushi Armed Security is a fully statutorily compliant business and 
                        accredited with the Private Security Industry Regulatory Authority.

                    </p>
                </div>
                <hr>
                <div class="Cont">
                    <div class="Left_Column">
                        
                       <?php
                       echo "<style text='css/stylesheet'>
                            #checkBox{
                                text-align: left; 
                                float: left;
                            }
                            .sendQuotation{
                                width: 100%;
                                height: 100%;
                                box-shadow: 0 2px 8px #000;
                                padding: 1%;
                                
                              }
                              
                              .sendQuotation #email{
                                width: 95%;
                                margin-top: 10px;
                    
                                height: 40px;
                              }
                              .sendQuotation h3{
                                  background: #071b30fa;
                                  margin-top: 0px;
                                  color: #fff;
                                  line-height: 30px;
                                  font-family: sans-serif;
                              }
                             
                                
                       </style><form class='sendQuotation'>
                       <h3>Get Quotation</h3>
                            <input type='email' name='Email' placeholder='Enter email address' id='email' required><br>
                            <input type='checkbox' name='k9-Quote' id='checkBox'>K9 Patrol Unit</input><br>
                            <input type='checkbox' name='Vip-Quote' id='checkBox'>VIP Personnel Protection</input><br>
                            <input type='checkbox' name='ArmedEs-Quote' id='checkBox'>Armed Escort</input><br>
                            <input type='checkbox' name='BdyG-Quote' id='checkBox'>Bodyguard Services</input><br>
                            </form>";
                       ?> 
                    </div>

                    <div class="Mid_Column">
                        <h3>Our Services</h3>
                        <div class='firstTwo'>
                                <a href="./views/Services.php"> <img src="./images/k9-4.jpg" width=160 height=150><p>We Offer K9 Patrol units to guard around homes, estates, 
                            as well as Police force. Our Dogs are also trained to sniff out narcotics.</p></a>
                            <a href="./views/Services.php"><img src="./images/vip.jpg" width=160 height=150><p>Our VIP Close Personnel Protection details offers a 
                                24 Hour VIP protection and escort at events or to serve as a protection detail.</p></a>
                        </div>
                      
                        <div class='lastTwo'>
                                <a href="./views/Services.php"><img src="./images/bdg.jpg" width=160 height=150><p>Our Body guarding detail offers a 24 hour protection and 
                                escort at events and private properties. Also includes 24 hour surveillance at private properties.</p></a>
                            <a href="./views/Services.php"><img src="./images/amd2.jpg" width=160 height=150><p>Our Armred Escort services offers a 24 hour armred 
                                response and surveillance on private protection, events, and events with high profile people. We also offer Armred Escort 
                                to high profile people</p></a>
                        </div>
                      
                           
                    </div>

                    <div class="Right_Column">
                        <div class='cmtArea'>
                        <h3>Reviews And Comments</h3>
                       <iframe with=100% height=90% src='./views/viewComments.php' frameborder=0></iframe>
                        </div>
                    </div>
                </div><br>
               
                
                </div>
            </div>
    </div>
       
</body>
<footer>
<div class="container">
                     <div class="col-1">
                        <h3>Where Are We Located</h3>
                        <P>Hello jfvvjhf</P>
                    </div>
                    <div class="col-2">
                    <h3>Get in touch with us</h3>
                    <a href="./Views/contact_us.php"><i class="far fa-envelope"></i>Send us an Email</a><br>
                    <a hre="#"><i class="far fa-phone"></i>Call us on (+27)87 630 0257</a>
                    </div>
                    <div class="col-3">
                    <h3>Get Quotation</h3>
                        <a href="./Views/LoginForm.php">Get K9 Patrol Unit quotation</a><br>
                        <a href="./Views/LoginForm.php">Get Physical Guard service quotation</a><br>
                        <a href="./Views/LoginForm.php">Get Our Armed Escort service quotation</a><br>
                        <a href="./Views/LoginForm.php">VIP Close Personnel Protection quotation</a>
                    </div>
                        <div class="col-4">
                              <h3>Follow us</h3>
                                <div class="icons">
                                <a href="https://facebook.com"><img src="./images/fb-icon.jpg"
                                                    width= "25px"
                                                    height= "25px"></a><span></span>
                                <a href="https://twitter.com"><img src="./images/twtr-icon.jpg"
                                                    width= "25px"
                                                    height= "25px"></a><span></span>
                                <a href="https://instagram.com"><img src="./images/ig-icon.jpg"
                                                    width= "25px"
                                                    height= "25px"></a>
    
                         </div>
                    </div>
</footer>